'use server';

import { cookies, headers } from 'next/headers';
import { dominioDoCookie } from './dominios';
import bcrypt from 'bcryptjs';
import { query } from './db';
import { mapPropertyRow, mapDevelopmentRow, heightFromId, toStringArray, miniValida, type PropertyRow, type DevelopmentRow } from './db-mappers';
import { signSession, veTudo, type StaffRole, type StaffSessionPayload } from './session';
import { staffAtual, exigirEquipe, exigirAdmin, exigirGestor } from './staff-auth';
import { dentroDoLimite, registrarUso, ipDoVisitante } from './limites';
import { lerPerfilFeed } from './perfil';
import { miniaturaDe, processarMiniaturas } from './miniaturas';
import type { PropertyDetail, Development } from './property-details';
import { countActiveFilters, type FilterState } from './filters';
import { TIPO_UNIDADE_LABEL, type TipoUnidade } from './tipologias';
import { r2PublicBase, cleanPhotoUrl } from './r2-url';
import { formatTitulo } from './text';
import { enviarEmail, emailConfigurado, emailLayout, escapeHtml } from './email';
import { SITE_URL } from './seo';
import { chaveNome, mesmoCondominio } from './planilha-condominios';
import { depoimentosAtivos, destaquesAtivos, hashTexto } from './especiais';
import { MESES, FASES_EXIGEM_CONCEPCAO, getStatusBucket } from './classification';
import { gravarConcepcao, resolverEmpresaImport, acrescentarConcepcao } from './empresas';
import { gravarProprietariosDoImovel } from './proprietarios';
import { corretoresPublicos, comCorretores } from './corretores';
import type { EmpresaPlanilha } from './planilha-condominios';
import type { EmpresaNaConcepcao } from './empresas-tipos';
import type { DepoimentoCard, DestaqueCard } from './especiais-tipos';
import { urlImovel } from './urls';

const PAGE_SIZE = 24;
const STAFF_COOKIE = 'mn_staff';

// ---------------- Feed (Comprar + Lançamentos) — leitura paginada e filtrada ----------------
// O feed mistura dois tipos de card: imóveis (tabela `properties`) e
// empreendimentos/condomínios (tabela `developments`). O modo "lancamentos"
// mostra só empreendimentos e imóveis avulsos com entrega no futuro.
// Paginação por offset por enquanto — trocar por cursor (created_at + id)
// antes do catálogo chegar a dezenas de milhares de linhas.
export type DevelopmentCardData = {
  id: string;
  slug?: string;
  concepcao?: string | null; // construtoras/incorporadoras, ex.: "Consciente · EBM"
  destaqueTamanho?: 2 | 3;
  name: string;
  location: string;
  bairro?: string;
  cidade?: string;
  uf?: string;
  deliveryDate: string; // "AAAA-MM"
  photos: string[];
  videoUrl?: string;
  tiposUnidade: TipoUnidade[];
  minPrice: number | null;
  quartosMin: number | null;
  quartosMax: number | null;
  areaMin: number | null;
  areaMax: number | null;
  unitsCount: number;
  aceitaTemporada: boolean;
  height: number;
  visualizacoes: number;
  tipo: 'vertical' | 'horizontal';
  anuncios: number; // anúncios avulsos públicos ligados ao condomínio (bolinha no card)
  capaMini?: string;
};

export type FeedItem =
  | { kind: 'imovel'; property: PropertyDetail }
  | { kind: 'empreendimento'; development: DevelopmentCardData }
  | { kind: 'depoimento'; depoimento: DepoimentoCard; chave: string }
  | { kind: 'destaque'; destaque: DestaqueCard; chave: string };

// Fase pela data de entrega, em SQL (mesmas faixas de lib/classification.ts, em meses)
const MES_ATUAL = "date_trunc('month', now())";
function faseSql(col: string, fase: string): string | null {
  const m = (n: number) => `${MES_ATUAL} + interval '${n} months'`;
  switch (fase) {
    case 'breve_lancamento':
      return `${col} > ${m(MESES.breveLancamento)}`;
    case 'lancamento':
      return `${col} >= ${m(MESES.lancamento)} and ${col} <= ${m(MESES.breveLancamento)}`;
    case 'obras':
      return `${col} > now() and ${col} < ${m(MESES.lancamento)}`;
    case 'futuro': // qualquer fase antes da entrega
      return `${col} > now()`;
    case 'novo':
      return `${col} <= now() and ${col} >= ${m(-MESES.novo)}`;
    case 'seminovo':
      return `${col} < ${m(-MESES.novo)} and ${col} >= ${m(-MESES.seminovo)}`;
    case 'usado':
      return `${col} < ${m(-MESES.seminovo)} and ${col} >= ${m(-MESES.usado)}`;
    case 'antigo':
      return `${col} < ${m(-MESES.usado)}`;
    default:
      return null;
  }
}

// Depoimentos de clientes e destaques (propaganda própria) entram no meio do feed:
// no máximo 1 de cada por página de 24. Cada depoimento aparece uma vez por visita;
// os destaques se revezam. A ordem muda por visitante (semente da sessão).
async function intercalarEspeciais(items: FeedItem[], page: number): Promise<FeedItem[]> {
  if (items.length < 6) return items;
  const [deps, dests] = await Promise.all([depoimentosAtivos(), destaquesAtivos()]);
  if (!deps.length && !dests.length) return items;
  const semente = hashTexto(lerPerfilFeed().seed || 'x');
  const out = items.slice();
  if (dests.length) {
    const d = dests[(page + semente) % dests.length];
    const pos = Math.min(out.length, page === 0 ? 3 : 11);
    out.splice(pos, 0, { kind: 'destaque', destaque: d, chave: `x-${d.id}-${page}` });
    query('update destaques set exibicoes = exibicoes + 1 where id = $1', [d.id]).catch(() => {});
  }
  if (deps.length && page < deps.length) {
    const d = deps[(page + semente) % deps.length];
    const pos = Math.min(out.length, page === 0 ? 9 : 18);
    out.splice(pos, 0, { kind: 'depoimento', depoimento: d, chave: `t-${d.id}` });
  }
  return out;
}

// Busca sem acento e sem diferenciar maiúsculas ("goiania" acha "Goiânia")
const ACCENTS_FROM = 'áàâãäéèêëíìîïóòôõöúùûüç';
const ACCENTS_TO = 'aaaaaeeeeiiiiooooouuuuc';
const norm = (sqlExpr: string) => `translate(lower(${sqlExpr}), '${ACCENTS_FROM}', '${ACCENTS_TO}')`;
function normalizeText(text: string): string {
  return text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

// Palavras que não ajudam a busca ("apartamento no setor bueno" → "apartamento", "setor", "bueno")
const STOPWORDS = new Set(['de', 'da', 'do', 'das', 'dos', 'em', 'no', 'na', 'nos', 'nas', 'e', 'a', 'o', 'com', 'para', 'pra', 'um', 'uma']);

function searchTokens(q: string): string[] {
  return normalizeText(q)
    .replace(/[^a-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 1 && !STOPWORDS.has(t))
    .slice(0, 8);
}

// Rótulos dos tipos em texto, pra busca por "casa", "cobertura", "sobrado"...
// (tabela auxiliar `tl` montada uma vez no início da consulta)
const TIPOS_CTE = `tl(k, label) as (values ${Object.entries(TIPO_UNIDADE_LABEL)
  .map(([k, v]) => `('${k}', '${v.replace(/'/g, "''")}')`)
  .join(', ')})`;

// Ação pública: sempre o feed PÚBLICO (os privados nunca saem daqui).
/**
 * Destaques da equipe que combinam com a busca atual (já ordenados pelo perfil do
 * visitante): alimentam o espaço de 2 colunas que se reveza no feed.
 */
export async function getDestaquesFeed(filters: FilterState): Promise<FeedItem[]> {
  const r = await feedInterno(0, filters, false, true).catch(() => ({ items: [] as FeedItem[] }));
  return r.items.filter((i) => i.kind === 'imovel' || i.kind === 'empreendimento').slice(0, 12);
}

/** Equipe (admin/analista) marca ou desmarca um anúncio/condomínio como destaque do feed */
/** tamanho: 0 = sem destaque; 2 = 2 colunas; 3 = 2 colunas e 2 linhas (card grande) */
export async function marcarDestaqueFeed(tipo: 'imovel' | 'condominio', id: string, tamanho: 0 | 2 | 3): Promise<void> {
  const staff = await requireStaff();
  if (!veTudo(staff.role)) throw new Error('Só admin e analista escolhem os destaques.');
  await query(`update ${tipo === 'imovel' ? 'properties' : 'developments'} set destaque = $2, destaque_tamanho = $3 where id = $1`, [
    id,
    tamanho > 0,
    tamanho === 3 ? 3 : 2
  ]);
}

export async function getFeedPage(page: number, filters: FilterState): Promise<{ items: FeedItem[]; hasMore: boolean; total?: number }> {
  const r = await feedInterno(page, filters, false);
  return { ...r, items: await intercalarEspeciais(r.items, page) };
}

// Uso interno (não exportado → não vira endpoint): com ocultos=true devolve os
// privados, que só saem daqui mascarados (getAnunciosOcultos).
async function feedInterno(page: number, filters: FilterState, ocultos: boolean, soDestaques = false): Promise<{ items: FeedItem[]; hasMore: boolean; total?: number }> {
  page = Math.max(0, Math.min(500, Math.floor(Number(page) || 0)));
  // Os filtros vêm do navegador: limita tamanho de listas e textos
  const lista = <T,>(v: unknown, n: number): T[] => (Array.isArray(v) ? (v.slice(0, n) as T[]) : []);
  const numeros = (v: unknown): number[] =>
    Array.from(new Set(lista<unknown>(v, 5).map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 4)));
  // aceita o formato antigo (uma fase só, em texto) e o novo (lista)
  const fases = (v: unknown): FilterState['situacao'] =>
    (Array.isArray(v) ? v : typeof v === 'string' && v !== 'todas' ? [v] : [])
      .map(String)
      .filter((s) => faseSql('x', s) !== null)
      .slice(0, 8) as FilterState['situacao'];
  filters = {
    ...filters,
    tipos: lista<FilterState['tipos'][number]>(filters?.tipos, 30),
    quartos: numeros(filters?.quartos),
    vagas: numeros(filters?.vagas),
    banheiros: numeros(filters?.banheiros),
    situacao: fases(filters?.situacao),
    termos: lista<string>(filters?.termos, 5).map((t) => String(t).slice(0, 80)),
    locais: lista<FilterState['locais'][number]>(filters?.locais, 20).map((l) => ({
      ...l,
      nome: String(l?.nome ?? '').slice(0, 120),
      cidade: String(l?.cidade ?? '').slice(0, 80),
      id: l?.id ? String(l.id).slice(0, 80) : undefined
    }))
  };
  // a pessoa está buscando/filtrando? (aí os vendidos aparecem sempre, depois dos disponíveis)
  const buscando = countActiveFilters(filters) > 0;
  const params: unknown[] = [];
  const p = (value: unknown) => {
    params.push(value);
    return `$${params.length}`;
  };

  const propConds: string[] = [];
  const devConds: string[] = [];
  // Vendidos: privados nunca; feed inicial só os vendidos há até 15 dias; buscas sempre
  if (ocultos) propConds.push('p.vendido_em is null');
  else if (!buscando) propConds.push(`(p.vendido_em is null or p.vendido_em > now() - interval '${DIAS_VENDIDO_NO_FEED} days')`);
  // Destaques (2 colunas no feed): só os marcados pela equipe, dentro da mesma busca
  if (soDestaques) {
    propConds.push('p.destaque');
    devConds.push('d.destaque');
  }

  // ---- Condições dos imóveis (alias p, com o empreendimento em d) ----
  if (filters.finalidade !== 'todas') propConds.push(`p.finalidade = ${p(filters.finalidade)}`);
  const tipos = (filters.tipos ?? []).filter((t) => t in TIPO_UNIDADE_LABEL);
  const precoMin = filters.precoMin && filters.precoMin > 0 ? filters.precoMin : null;
  const precoMax = filters.precoMax && filters.precoMax > 0 ? filters.precoMax : null;
  const areaMin = filters.areaMin && filters.areaMin > 0 ? filters.areaMin : null;
  const areaMax = filters.areaMax && filters.areaMax > 0 ? filters.areaMax : null;
  if (tipos.length) propConds.push(`p.tipo_unidade = any(${p(tipos)}::text[])`);
  if (precoMin) propConds.push(`p.price_value >= ${p(precoMin)}`);
  if (precoMax) propConds.push(`p.price_value <= ${p(precoMax)}`);
  if (areaMin) propConds.push(`p.area >= ${p(areaMin)}`);
  if (areaMax) propConds.push(`p.area <= ${p(areaMax)}`);
  // Quartos / vagas / banheiros: valores marcados (4 = 4 ou mais; 0 = nenhum)
  const bate = (col: string, v: number[]) => {
    const a = p(v);
    return `(coalesce(${col}, 0) = any(${a}::int[]) or (4 = any(${a}::int[]) and coalesce(${col}, 0) >= 4))`;
  };
  if (filters.quartos.length) propConds.push(bate('p.quartos', filters.quartos));
  if (filters.vagas.length) propConds.push(bate('p.vagas', filters.vagas));
  if (filters.banheiros.length) propConds.push(bate('p.banheiros', filters.banheiros));
  if (filters.aceitaTemporada === 'sim') propConds.push('p.aceita_temporada = true');
  if (filters.modo === 'lancamentos') propConds.push('p.empreendimento_id is null and p.delivery_date > now()');

  // ---- Condições dos empreendimentos (alias d, resumo das unidades em u) ----
  if (filters.finalidade === 'aluguel') devConds.push('false');
  if (tipos.length) {
    const t = p(tipos);
    devConds.push(`(d.tipos_unidade ?| ${t}::text[] or coalesce(u.tipos, '[]'::jsonb) ?| ${t}::text[])`);
  }
  // Empreendimento entra se alguma tipologia cai dentro da faixa pedida
  if (precoMin) devConds.push(`u.max_price >= ${p(precoMin)}`);
  if (precoMax) devConds.push(`u.min_price <= ${p(precoMax)}`);
  if (areaMin) devConds.push(`u.max_area >= ${p(areaMin)}`);
  if (areaMax) devConds.push(`u.min_area <= ${p(areaMax)}`);
  // Empreendimento: basta uma tipologia (ou uma opção de quartos do cadastro) bater.
  // "0 quartos" = empreendimento comercial (salas, lojas).
  const bateLista = (lista: string, v: number[]) => {
    const a = p(v);
    return `exists (select 1 from jsonb_array_elements_text(${lista}) n where n.value::int = any(${a}::int[]) or (4 = any(${a}::int[]) and n.value::int >= 4))`;
  };
  const comercial = "d.tipos_unidade ?| array['sala_comercial','loja_ponto_comercial','galpao','predio_comercial']";
  if (filters.quartos.length)
    devConds.push(
      `(${bateLista("coalesce(u.quartos_set, '[]'::jsonb) || coalesce(d.quartos_opcoes, '[]'::jsonb)", filters.quartos)}${filters.quartos.includes(0) ? ` or ${comercial}` : ''})`
    );
  if (filters.vagas.length) devConds.push(bateLista("coalesce(u.vagas_set, '[]'::jsonb)", filters.vagas));
  if (filters.banheiros.length) devConds.push(bateLista("coalesce(u.banheiros_set, '[]'::jsonb)", filters.banheiros));
  if (filters.aceitaTemporada === 'sim') devConds.push('d.aceita_temporada = true');
  // Só condomínios publicados; as tipologias da tabela de vendas aparecem dentro do card do empreendimento
  devConds.push("d.status = 'publicado'"); // sem ano de entrega também aparece (com "----" no lugar do ano)
  // Para o público, o card do CONDOMÍNIO (com ou sem foto) entra no feed (Todos e
  // Lançamentos) se for LANÇAMENTO ou NOVO (entregue há até 36 meses) ou se tiver
  // ANÚNCIO ligado. Sem anúncio, só aparece quando a pessoa pesquisa o nome (e no
  // Google, pela página própria) — assim o feed não enche de condomínio vazio.
  // A equipe logada vê todos.
  const pesquisandoNome = (filters.termos ?? []).length > 0 || (filters.locais ?? []).some((l) => l.tipo === 'condominio');
  // (fica separado das outras condições: a CONTAGEM "N imóveis à venda" não usa esta regra)
  const soNoFeed: string[] = [];
  if (!pesquisandoNome && !await currentStaff())
    soNoFeed.push(
      "(d.delivery_date >= date_trunc('month', now()) - interval '60 months' or coalesce(u.avulsos, 0) > 0)"
    );
  propConds.push('p.is_tipologia = false');
  // Anúncios PRIVADOS (portfólio, sem autorização do proprietário para publicar)
  // não entram no feed; aparecem só mascarados na seção "reservados" no fim da busca.
  propConds.push(ocultos ? "p.visibilidade = 'privado'" : "p.visibilidade = 'publico'");
  if (ocultos) devConds.push('false');

  // ---- Condições que valem para os dois ----
  // várias fases marcadas: vale qualquer uma delas
  const situacaoSql = (col: string) => {
    const ors = filters.situacao.map((s) => faseSql(col, s)).filter(Boolean);
    return ors.length ? `(${ors.map((o) => `(${o})`).join(' or ')})` : null;
  };
  const sitP = situacaoSql('p.delivery_date');
  const sitD = situacaoSql('d.delivery_date');
  if (sitP) propConds.push(sitP);
  if (sitD) devConds.push(sitD);

  const anoMin = filters.anoMin && filters.anoMin > 1900 ? filters.anoMin : null;
  const anoMax = filters.anoMax && filters.anoMax > 1900 ? filters.anoMax : null;
  if (anoMin) {
    const v = p(anoMin);
    propConds.push(`extract(year from p.delivery_date) >= ${v}`);
    devConds.push(`extract(year from d.delivery_date) >= ${v}`);
  }
  if (anoMax) {
    const v = p(anoMax);
    propConds.push(`extract(year from p.delivery_date) <= ${v}`);
    devConds.push(`extract(year from d.delivery_date) <= ${v}`);
  }

  // Busca livre: cada palavra precisa aparecer em algum dos campos
  // Locais marcados (cidade / bairro / condomínio) — qualquer um deles serve
  const locais = (filters.locais ?? []).slice(0, 20);
  if (locais.length) {
    const propOr: string[] = [];
    const devOr: string[] = [];
    for (const l of locais) {
      const cid = p(l.cidade);
      const eqCid = (col: string) => `${norm(`coalesce(${col}, '')`)} = ${norm(`${cid}::text`)}`;
      if (l.tipo === 'cidade') {
        propOr.push(eqCid('p.cidade'));
        devOr.push(eqCid('d.cidade'));
      } else if (l.tipo === 'bairro') {
        const b = p(l.nome);
        propOr.push(`(${norm("coalesce(p.bairro, '')")} = ${norm(`${b}::text`)} and ${eqCid('p.cidade')})`);
        devOr.push(`(${norm("coalesce(d.bairro, '')")} = ${norm(`${b}::text`)} and ${eqCid('d.cidade')})`);
      } else {
        const n = p(l.nome);
        const nomeIgual = (col: string) => `${norm(`coalesce(${col}, '')`)} = ${norm(`${n}::text`)}`;
        if (l.id) {
          const id = p(l.id);
          propOr.push(`(p.empreendimento_id = ${id} or (${nomeIgual('p.condominio')} and ${eqCid('p.cidade')}))`);
          devOr.push(`d.id = ${id}`);
        } else {
          propOr.push(`(${nomeIgual('p.condominio')} and ${eqCid('p.cidade')})`);
          devOr.push(`(${nomeIgual('d.name')} and ${eqCid('d.cidade')})`);
        }
      }
    }
    propConds.push(`(${propOr.join(' or ')})`);
    devConds.push(`(${devOr.join(' or ')})`);
  }

  // Balões de busca: (todas as palavras do balão 1) OU (todas as palavras do balão 2) ...
  const grupos = (filters.termos ?? []).map(searchTokens).filter((g) => g.length);
  if (grupos.length) {
    const propOr: string[] = [];
    const devOr: string[] = [];
    for (const tokens of grupos) {
      const vs = tokens.map((t) => p(`%${t}%`));
      propOr.push(`(${vs.map((v) => `pt.txt like ${v}`).join(' and ')})`);
      devOr.push(`(${vs.map((v) => `dx.txt like ${v}`).join(' and ')})`);
    }
    propConds.push(`(${propOr.join(' or ')})`);
    devConds.push(`(${devOr.join(' or ')})`);
  }

  const where = (conds: string[]) => (conds.length ? `where ${conds.join(' and ')}` : '');

  // mesmas junções na lista e na contagem
  const fromImovel = `from properties p
         left join developments pd on pd.id = p.empreendimento_id
         left join tl ptl on ptl.k = p.tipo_unidade
         cross join lateral (
           select ${norm(`concat_ws(' ', p.titulo, p.location, p.bairro, p.cidade, p.condominio, pd.name, ptl.label, (select string_agg(concat_ws(' ', e.nome_perfil, e.nome_fantasia, e.razao_social), ' ') from development_empresas de join empresas e on e.id = de.empresa_id where de.development_id = pd.id))`)} as txt
         ) pt
`;
  const fromCondo = `from developments d
         left join lateral (
           select min(x.price_value) filter (where x.price_value > 0) as min_price,
                  max(x.price_value) as max_price,
                  min(x.area) as min_area,
                  max(x.area) as max_area,
                  max(x.quartos) as max_quartos,
                  max(x.vagas) as max_vagas,
                  coalesce(jsonb_agg(distinct x.quartos) filter (where x.quartos is not null), '[]'::jsonb) as quartos_set,
                  coalesce(jsonb_agg(distinct x.vagas) filter (where x.vagas is not null), '[]'::jsonb) as vagas_set,
                  coalesce(jsonb_agg(distinct x.banheiros) filter (where x.banheiros is not null), '[]'::jsonb) as banheiros_set,
                  jsonb_agg(distinct x.tipo_unidade) as tipos,
                  count(x.id) as n,
                  count(x.id) filter (where not x.is_tipologia and x.vendido_em is null) as avulsos,
                  string_agg(distinct xtl.label, ' ') as tipos_texto
             from properties x left join tl xtl on xtl.k = x.tipo_unidade
            where x.empreendimento_id = d.id and x.visibilidade = 'publico'
         ) u on true
         left join lateral (
           select max(v::int) as max_quartos from jsonb_array_elements_text(d.quartos_opcoes) v
         ) dq on true
         left join lateral (
           select string_agg(ttl.label, ' ') as tipos_texto
             from jsonb_array_elements_text(d.tipos_unidade) t left join tl ttl on ttl.k = t
         ) dt on true
         cross join lateral (
           select ${norm(`concat_ws(' ', d.name, d.location, d.bairro, d.cidade, 'empreendimento condominio lancamento', u.tipos_texto, dt.tipos_texto, (select string_agg(concat_ws(' ', e.nome_perfil, e.nome_fantasia, e.razao_social), ' ') from development_empresas de join empresas e on e.id = de.empresa_id where de.development_id = d.id))`)} as txt
         ) dx
`;

  // Contagem do cabeçalho ("N imóveis à venda"), SEMPRE conforme os filtros:
  // anúncios avulsos que atendem a busca (sem os vendidos) + condomínios que atendem
  // a busca e são lançamento, novo ou seminovo (entregues há até 6 anos).
  let total: number | undefined;
  if (page === 0 && !ocultos) {
    const soVenda = filters.finalidade === 'todas' ? " and p.finalidade = 'venda'" : '';
    const paramsConta = params.slice(); // antes dos parâmetros da ordem (não usados aqui)
    const condImovel = where([...propConds, `p.vendido_em is null${soVenda}`]);
    const condCondo = where([...devConds, "d.delivery_date >= date_trunc('month', now()) - interval '60 months'"]);
    const r = await query<{ n: string }>(
      `with ${TIPOS_CTE}
       select (select count(*) ${fromImovel} ${condImovel})
            + (select count(*) ${fromCondo} ${condCondo}) as n`,
      paramsConta
    ).catch(() => []);
    total = r[0] ? Number(r[0].n) || 0 : undefined;
  }

  // ---- ORDEM DO FEED ----
  // Aleatória por visita (a "semente" muda a cada sessão do navegador e fica fixa
  // enquanto a pessoa rola a página — assim nada repete nem some entre páginas),
  // com pesos que puxam para cima:
  //   vídeo (autoplay é a marca do portal) · com foto · anúncio novo (10 dias) ·
  //   lançamento/novo · o PERFIL da pessoa (tipos, bairros e faixa de preço que ela
  //   buscou ou abriu — cookie mn_perfil).
  const perfil = lerPerfilFeed();
  const seed = p(perfil.seed);
  const rnd = (col: string) => `(('x' || substr(md5(${col} || ${seed}::text), 1, 8))::bit(32)::bigint / 4294967295.0)`;
  const pTipos = p(perfil.tipos);
  const pBairros = p(perfil.bairros.map((b) => normalizeText(b)));
  const pMin = p(perfil.precoMin);
  const pMax = p(perfil.precoMax);
  const bairroNorm = (col: string) => norm(`coalesce(${col}, '')`);
  const scoreImovel = `(${rnd('p.id')}
      + case when p.video_url is not null and p.video_url <> '' then 0.45 else 0 end
      + case when jsonb_array_length(coalesce(p.photos, '[]'::jsonb)) = 0 then -0.6 else 0 end
      + case when p.created_at > now() - interval '10 days' then 0.25 else 0 end
      + case when p.delivery_date >= now() - interval '60 months' then 0.1 else 0 end
      + case when p.vendido_em is not null then -0.3 else 0 end
      + case when p.tipo_unidade = any(${pTipos}::text[]) then 0.35 else 0 end
      + case when ${bairroNorm('p.bairro')} = any(${pBairros}::text[]) then 0.35 else 0 end
      + case when ${pMin}::numeric is not null and p.price_value between ${pMin}::numeric and ${pMax}::numeric then 0.2 else 0 end)`;
  const scoreCondo = `(${rnd('d.id')}
      + case when d.video_url is not null and d.video_url <> '' then 0.45 else 0 end
      + case when jsonb_array_length(coalesce(d.photos, '[]'::jsonb)) = 0 then -0.35 else 0 end
      + case when d.delivery_date >= now() - interval '60 months' then 0.2 else 0 end
      + case when coalesce(d.tipos_unidade, '[]'::jsonb) ?| ${pTipos}::text[] or coalesce(u.tipos, '[]'::jsonb) ?| ${pTipos}::text[] then 0.25 else 0 end
      + case when ${bairroNorm('d.bairro')} = any(${pBairros}::text[]) then 0.35 else 0 end)`;

  params.push(PAGE_SIZE + 1, page * PAGE_SIZE);
  const limitIdx = params.length - 1;
  const offsetIdx = params.length;

  const rows = await query<{ kind: 'imovel' | 'empreendimento'; id: string }>(
    `with ${TIPOS_CTE}
     select kind, id from (
       select 'imovel' as kind, p.id, ${scoreImovel} as score
         ${fromImovel}
         ${where(propConds)}
       union all
       select 'empreendimento' as kind, d.id, ${scoreCondo} as score
         ${fromCondo}
         ${where([...devConds, ...soNoFeed])}
     ) feed
     order by score desc, id
     limit $${limitIdx} offset $${offsetIdx}`,
    params
  );

  const hasMore = rows.length > PAGE_SIZE;
  const pageRows = rows.slice(0, PAGE_SIZE);
  const propIds = pageRows.filter((r) => r.kind === 'imovel').map((r) => r.id);
  const devIds = pageRows.filter((r) => r.kind === 'empreendimento').map((r) => r.id);

  const [propRows, devCards] = await Promise.all([
    propIds.length ? query<PropertyRow>('select * from properties where id = any($1::text[])', [propIds]) : Promise.resolve([]),
    devIds.length ? getDevelopmentCards(devIds) : Promise.resolve([])
  ]);
  // corretor responsável no card: foto, nome e CRECI (nunca o e-mail)
  const corretores = await corretoresPublicos(propRows.map((r) => r.corretor_email));
  const propMap = new Map(propRows.map((r) => [r.id, { ...mapPropertyRow(r), corretor: corretores.get((r.corretor_email ?? '').toLowerCase()) }]));
  const devMap = new Map(devCards.map((d) => [d.id, d]));

  const items: FeedItem[] = [];
  for (const r of pageRows) {
    if (r.kind === 'imovel') {
      const property = propMap.get(r.id);
      if (property) items.push({ kind: 'imovel', property });
    } else {
      const development = devMap.get(r.id);
      if (development) items.push({ kind: 'empreendimento', development });
    }
  }
  return { items, hasMore, total };
}

/** Cards de condomínio na ordem pedida (usado pela página de favoritos) */
export async function cardsDeCondominios(ids: string[]): Promise<DevelopmentCardData[]> {
  const lista = (Array.isArray(ids) ? ids : []).filter((x) => typeof x === 'string').slice(0, 100);
  if (!lista.length) return [];
  const cards = await getDevelopmentCards(lista);
  const pos = new Map(lista.map((id, i) => [id, i]));
  return cards.sort((x, y) => (pos.get(x.id) ?? 0) - (pos.get(y.id) ?? 0));
}

async function getDevelopmentCards(ids: string[]): Promise<DevelopmentCardData[]> {
  const rows = await query<
    DevelopmentRow & {
      min_price: string | null;
      q_min: number | null;
      q_max: number | null;
      a_min: string | null;
      a_max: string | null;
      n: string;
      unit_tipos: unknown;
      anuncios: string;
      concepcao: string | null;
    }
  >(
    `select d.*, u.min_price, u.q_min, u.q_max, u.a_min, u.a_max, u.n, u.unit_tipos, u.anuncios,
            (select string_agg(coalesce(nullif(e.nome_perfil, ''), nullif(e.nome_fantasia, ''), e.razao_social), ' · ' order by de.ordem)
               from development_empresas de join empresas e on e.id = de.empresa_id where de.development_id = d.id) as concepcao
       from developments d
       left join lateral (
         select min(x.price_value) filter (where x.price_value > 0) as min_price,
                min(x.quartos) as q_min, max(x.quartos) as q_max,
                min(x.area) as a_min, max(x.area) as a_max,
                count(*) as n, jsonb_agg(distinct x.tipo_unidade) as unit_tipos,
                count(*) filter (where not x.is_tipologia and x.vendido_em is null) as anuncios
           from properties x where x.empreendimento_id = d.id and x.visibilidade = 'publico'
       ) u on true
      where d.id = any($1::text[])`,
    [ids]
  );
  return rows.map((row) => {
    const base = mapDevelopmentRow(row, []);
    const tipos = Array.from(new Set([...(base.tiposUnidade ?? []), ...(toStringArray(row.unit_tipos) as TipoUnidade[])]));
    const quartos = [...(base.quartosOpcoes ?? []), ...[row.q_min, row.q_max].filter((n): n is number => n != null)];
    return {
      id: base.id,
      slug: base.slug,
      name: base.name,
      location: base.location,
      bairro: base.bairro,
      cidade: base.cidade,
      uf: base.uf,
      deliveryDate: base.deliveryDate,
      photos: base.photos ?? [],
      videoUrl: base.videoUrl,
      tiposUnidade: tipos,
      minPrice: row.min_price != null ? Number(row.min_price) : null,
      quartosMin: quartos.length ? Math.min(...quartos) : null,
      quartosMax: quartos.length ? Math.max(...quartos) : null,
      areaMin: row.a_min != null ? Number(row.a_min) : null,
      areaMax: row.a_max != null ? Number(row.a_max) : null,
      unitsCount: Number(row.n) || 0,
      aceitaTemporada: base.aceitaTemporada,
      height: heightFromId(base.id) + 40,
      visualizacoes: Number(row.visualizacoes) || 0,
      tipo: base.tipo,
      anuncios: Number(row.anuncios) || 0,
      capaMini: miniValida(row),
      concepcao: row.concepcao ?? null,
      destaqueTamanho: (row as { destaque_tamanho?: number }).destaque_tamanho === 3 ? 3 : 2
    };
  });
}

// ---------------- Índice de locais para a busca ----------------
// Só lugares onde EXISTE anúncio publicado (a lista cresce sozinha conforme
// os cadastros entram). Agrupa grafias diferentes ("Goiania"/"Goiânia").
export type LocalSugestao = {
  tipo: 'cidade' | 'bairro' | 'condominio';
  nome: string;
  cidade: string;
  uf: string;
  id?: string; // condomínio cadastrado (empreendimento)
  total: number;
};

export async function getLocationIndex(): Promise<LocalSugestao[]> {
  const rows = await query<{ tipo: 'cidade' | 'bairro' | 'condominio'; nome: string; cidade: string; uf: string | null; id: string | null; total: string }>(
    `with anuncios as (
       select p.bairro, p.cidade, p.uf, coalesce(pd.name, p.condominio) as condominio, pd.id as dev_id
         from properties p left join developments pd on pd.id = p.empreendimento_id
        where p.is_tipologia = false and p.visibilidade = 'publico' and p.cidade is not null
       union all
       select d.bairro, d.cidade, d.uf, d.name, d.id
         from developments d where d.status = 'publicado' and d.cidade is not null
          -- condomínio só entra na lista de locais se tiver foto ou imóvel (os milhares importados
          -- por planilha continuam achados pela busca digitada, sem pesar a lista)
          and (jsonb_array_length(coalesce(d.photos, '[]'::jsonb)) > 0 or exists (select 1 from properties x where x.empreendimento_id = d.id and x.visibilidade = 'publico'))
     ),
     cidades as (
       select 'cidade' as tipo, mode() within group (order by cidade) as nome, mode() within group (order by cidade) as cidade,
              max(uf) as uf, null::text as id, count(*) as total
         from anuncios group by ${norm('cidade')}
     ),
     bairros as (
       select 'bairro' as tipo, mode() within group (order by bairro) as nome, mode() within group (order by cidade) as cidade,
              max(uf) as uf, null::text as id, count(*) as total
         from anuncios where bairro is not null group by ${norm('bairro')}, ${norm('cidade')}
     ),
     condos as (
       select 'condominio' as tipo, mode() within group (order by condominio) as nome, mode() within group (order by cidade) as cidade,
              max(uf) as uf, max(dev_id) as id, count(*) as total
         from anuncios where condominio is not null group by ${norm('condominio')}, ${norm('cidade')}
     )
     select * from cidades union all select * from bairros union all select * from condos
     order by total desc`
  );
  return rows.map((r) => ({ tipo: r.tipo, nome: formatTitulo(r.nome), cidade: r.cidade, uf: r.uf ?? '', id: r.id ?? undefined, total: Number(r.total) || 0 }));
}

// ---------------- Reconhecimento de condomínio pelo CEP ----------------
export type CondominioSugestao = { kind: 'empreendimento' | 'condominio'; id?: string; nome: string };

export async function findCondominiosByCep(cep: string): Promise<CondominioSugestao[]> {
  const digits = String(cep).replace(/\D/g, '');
  if (digits.length !== 8) return [];
  const [devs, condos] = await Promise.all([
    query<{ id: string; name: string }>('select id, name from developments where cep = $1 order by name limit 10', [digits]),
    query<{ condominio: string }>(
      `select distinct condominio from properties
        where cep = $1 and condominio is not null and condominio <> '' and empreendimento_id is null
        order by condominio limit 10`,
      [digits]
    )
  ]);
  const devNames = new Set(devs.map((d) => normalizeText(d.name)));
  return [
    ...devs.map((d) => ({ kind: 'empreendimento' as const, id: d.id, nome: d.name })),
    ...condos.filter((c) => !devNames.has(normalizeText(c.condominio))).map((c) => ({ kind: 'condominio' as const, nome: c.condominio }))
  ];
}

// ---------------- Sessão da equipe (servidor) ----------------
// Sessão conferida no banco a cada requisição (lib/staff-auth.ts)
const currentStaff = staffAtual;
const requireStaff = exigirEquipe;
// Admin mexe em tudo; corretor só no que ele mesmo cadastrou
async function assertCanEdit(table: 'properties' | 'developments', id: string, staff: StaffSessionPayload) {
  if (veTudo(staff.role)) return;
  const rows = await query<{ corretor_email: string | null }>(`select corretor_email from ${table} where id = $1`, [id]);
  if (!rows[0] || rows[0].corretor_email !== staff.email) throw new Error('Você só pode editar o que cadastrou.');
}

// ---------------- Leitura para as páginas públicas ----------------
// Anúncio privado só volta completo para a equipe ou com a chave do link privado
// Privado só volta completo para a equipe (o cliente usa o link pessoal — lib/links-privados.ts)
export async function getPropertyById(id: string): Promise<PropertyDetail | null> {
  const rows = await query<PropertyRow>('select * from properties where id = $1', [id]);
  const r = rows[0];
  if (!r) return null;
  if (r.visibilidade === 'privado' && !await currentStaff()) return null;
  const c = await corretoresPublicos([r.corretor_email]);
  return { ...mapPropertyRow(r), corretor: c.get((r.corretor_email ?? '').toLowerCase()) };
}

// Condomínio em rascunho só aparece para quem está logado no painel
export async function getDevelopmentById(id: string): Promise<Development | null> {
  const devRows = await query<DevelopmentRow>('select * from developments where id = $1', [id]);
  const dev = devRows[0];
  if (!dev) return null;
  if (dev.status === 'rascunho' && !await currentStaff()) return null;
  const unitRows = await query<PropertyRow>(
    "select * from properties where empreendimento_id = $1 and visibilidade = 'publico' order by is_tipologia desc, area asc nulls last",
    [id]
  );
  return mapDevelopmentRow(dev, unitRows.map(mapPropertyRow));
}

export async function getPropertiesByCorretor(email: string, isAdmin: boolean): Promise<PropertyDetail[]> {
  const staff = await requireStaff();
  const rows =
    veTudo(staff.role) && isAdmin
      ? await query<PropertyRow>('select * from properties where corretor_email is not null and is_tipologia = false order by created_at desc')
      : await query<PropertyRow>('select * from properties where corretor_email = $1 and is_tipologia = false order by created_at desc', [staff.email]);
  // e-mail do corretor só vai para o painel (nunca nas páginas públicas)
  return rows.map((r) => ({ ...mapPropertyRow(r), corretorEmail: r.corretor_email ?? undefined }));
}

export async function getAllPropertyIds(): Promise<string[]> {
  const rows = await query<{ id: string }>("select id from properties where visibilidade = 'publico' and is_tipologia = false and vendido_em is null");
  return rows.map((r) => r.id);
}

export async function getAllDevelopmentIds(): Promise<string[]> {
  const rows = await query<{ id: string }>("select id from developments where status = 'publicado'");
  return rows.map((r) => r.id);
}

// ---------------- Relacionados (fim das páginas) ----------------
// "Imóveis disponíveis neste condomínio" e "Imóveis nesta região".
// Região = mesma cidade, mesma finalidade, mesmo grupo de tipo (apartamentos
// com apartamentos, casas com casas...), preço até 35% abaixo ou acima.
// Dentro disso, ordena pelo PERFIL do imóvel que a pessoa está vendo:
// quantidade de quartos pesa mais, depois metragem parecida, depois mesmo
// bairro e preço mais próximo. A idade do imóvel não conta (de propósito:
// um usado bem parecido pode ser uma ótima sugestão para quem olha um novo).
export type RelatedListings = {
  mesmoCondominio: PropertyDetail[];
  regiao: PropertyDetail[]; // similares (mesmo perfil: tipo, preço, quartos, metragem)
  mesmoBairro?: PropertyDetail[]; // outros à venda no mesmo bairro (qualquer perfil)
  precoReferencia: number | null;
};

const GRUPO_TIPO: Record<string, string> = {
  studio: 'vertical', flat: 'vertical', loft: 'vertical', apartamento: 'vertical', apartamento_garden: 'vertical',
  apartamento_duplex: 'vertical', apartamento_triplex: 'vertical', cobertura: 'vertical', cobertura_duplex: 'vertical', penthouse: 'vertical',
  casa: 'casa', casa_condominio: 'casa', sobrado: 'casa',
  chacara_sitio_fazenda: 'terra', terreno_lote: 'terra',
  sala_comercial: 'comercial', loja_ponto_comercial: 'comercial', galpao: 'comercial', predio_comercial: 'comercial'
};
const MARGEM_PRECO = 0.35;

export async function getRelatedListings(target: { propertyId?: string; developmentId?: string }): Promise<RelatedListings> {
  type Base = { id?: string; devId: string | null; condominio: string | null; bairro: string | null; cidade: string | null; finalidade: string; price: number | null; quartos: number | null; area: number | null; grupos: string[] };
  let base: Base | null = null;
  const vazio: RelatedListings = { mesmoCondominio: [], regiao: [], precoReferencia: null };

  if (target.propertyId) {
    const r = await query<{ id: string; empreendimento_id: string | null; condominio: string | null; bairro: string | null; cidade: string | null; finalidade: string; price_value: string; quartos: number | null; area: string | null; tipo_unidade: string }>(
      'select id, empreendimento_id, condominio, bairro, cidade, finalidade, price_value, quartos, area, tipo_unidade from properties where id = $1',
      [target.propertyId]
    );
    if (!r[0]) return vazio;
    base = {
      id: r[0].id, devId: r[0].empreendimento_id, condominio: r[0].condominio, bairro: r[0].bairro, cidade: r[0].cidade, finalidade: r[0].finalidade,
      price: Number(r[0].price_value) || null, quartos: r[0].quartos, area: r[0].area != null ? Number(r[0].area) : null,
      grupos: [GRUPO_TIPO[r[0].tipo_unidade] ?? 'vertical']
    };
  } else if (target.developmentId) {
    const r = await query<{ id: string; name: string; bairro: string | null; cidade: string | null; tipos_unidade: unknown; min_price: string | null; q: string | null; a: string | null; unit_tipos: unknown }>(
      `select d.id, d.name, d.bairro, d.cidade, d.tipos_unidade,
              (select min(price_value) filter (where price_value > 0) from properties where empreendimento_id = d.id) as min_price,
              (select round(avg(quartos)) from properties where empreendimento_id = d.id) as q,
              (select avg(area) from properties where empreendimento_id = d.id) as a,
              (select jsonb_agg(distinct tipo_unidade) from properties where empreendimento_id = d.id) as unit_tipos
         from developments d where d.id = $1`,
      [target.developmentId]
    );
    if (!r[0]) return vazio;
    const tipos = [...toStringArray(r[0].tipos_unidade), ...toStringArray(r[0].unit_tipos)];
    base = {
      devId: r[0].id, condominio: r[0].name, bairro: r[0].bairro, cidade: r[0].cidade, finalidade: 'venda',
      price: r[0].min_price ? Number(r[0].min_price) : null, quartos: r[0].q ? Number(r[0].q) : null, area: r[0].a ? Number(r[0].a) : null,
      grupos: Array.from(new Set(tipos.map((t) => GRUPO_TIPO[t]).filter(Boolean)))
    };
  }
  if (!base) return vazio;

  // Mesmo condomínio: vinculados ao empreendimento ou com o mesmo nome de condomínio na mesma cidade
  const condoRows = await query<PropertyRow>(
    `select * from properties
      where is_tipologia = false and visibilidade = 'publico' and id <> $1
        and (($2::text is not null and empreendimento_id = $2)
          or ($3::text is not null and ${norm('condominio')} = ${norm('$3::text')} and ${norm("coalesce(cidade, '')")} = ${norm("coalesce($4::text, '')")}))
      order by (vendido_em is not null), vendido_em desc nulls first, created_at desc limit 12`,
    [base.id ?? '', base.devId, base.condominio, base.cidade]
  );
  if (!base.cidade) return { mesmoCondominio: await comCorretores(condoRows, mapPropertyRow), regiao: [], precoReferencia: base.price };

  const excluir = [base.id ?? '', ...condoRows.map((r) => r.id)];
  const tiposDoGrupo = Object.entries(GRUPO_TIPO)
    .filter(([, g]) => !base!.grupos.length || base!.grupos.includes(g))
    .map(([t]) => t);

  const params: unknown[] = [excluir, base.cidade, base.bairro, base.finalidade, tiposDoGrupo];
  const p = (v: unknown) => {
    params.push(v);
    return `$${params.length}`;
  };
  const conds = [
    'is_tipologia = false',
    "visibilidade = 'publico'",
    'not (id = any($1::text[]))',
    `${norm("coalesce(cidade, '')")} = ${norm('$2::text')}`,
    'finalidade = $4',
    'tipo_unidade = any($5::text[])'
  ];
  const score: string[] = [
    `(case when ${norm("coalesce(bairro, '')")} = ${norm("coalesce($3::text, '')")} then 0 else 1 end)`,
    // vendidos continuam aparecendo (escassez), mas depois dos disponíveis parecidos
    '(case when vendido_em is not null then 1.5 else 0 end)'
  ];
  if (base.price) {
    const pr = p(base.price);
    conds.push(`price_value between ${pr} * ${1 - MARGEM_PRECO} and ${pr} * ${1 + MARGEM_PRECO}`);
    score.push(`abs(price_value - ${pr}) / ${pr} * 2`);
  }
  if (base.quartos) {
    const q = p(base.quartos);
    score.push(`coalesce(abs(quartos - ${q}), 2) * 3`); // cada quarto de diferença pesa muito
  }
  if (base.area) {
    const a = p(base.area);
    score.push(`coalesce(abs(area - ${a}) / ${a}, 0.5) * 4`); // 25% de diferença na metragem ≈ 1 quarto
  }
  const regiaoRows = await query<PropertyRow>(
    `select * from properties where ${conds.join(' and ')} order by (${score.join(' + ')}) asc, created_at desc limit 8`,
    params
  );
  // Outros no mesmo bairro (qualquer tipo/preço), sem repetir os anteriores; vendidos depois
  const bairroRows = base.bairro
    ? await query<PropertyRow>(
        `select * from properties
          where is_tipologia = false and visibilidade = 'publico' and finalidade = $4
            and not (id = any($1::text[])) and ${norm("coalesce(cidade, '')")} = ${norm('$2::text')} and ${norm("coalesce(bairro, '')")} = ${norm('$3::text')}
          order by (vendido_em is not null), (jsonb_array_length(coalesce(photos, '[]'::jsonb)) = 0), created_at desc limit 8`,
        [[...excluir, ...regiaoRows.map((r) => r.id)], base.cidade, base.bairro, base.finalidade]
      ).catch(() => [])
    : [];
  return {
    mesmoCondominio: await comCorretores(condoRows, mapPropertyRow),
    regiao: await comCorretores(regiaoRows, mapPropertyRow),
    mesmoBairro: await comCorretores(bairroRows, mapPropertyRow),
    precoReferencia: base.price
  };
}

// ---------------- Cadastro (painel) — escrita ----------------
export type CreatePropertyInput = {
  id: string;
  titulo?: string;
  tipoUnidade: TipoUnidade;
  finalidade: 'venda' | 'aluguel';
  deliveryDate: string; // "AAAA-MM"
  priceValue: number;
  pricePeriod: 'unico' | 'mensal';
  location: string;
  quartos?: number;
  vagas?: number;
  banheiros?: number;
  escaninhos?: number;
  area?: number;
  video: boolean;
  videoUrl?: string;
  videoVertical?: boolean; // vídeo gravado em pé (celular) — ocupa o espaço sem faixas pretas
  aceitaTemporada: boolean;
  description: string;
  amenities: string[];
  empreendimentoId?: string;
  corretorEmail?: string; // ignorado — o corretor vem sempre do login
  photos?: string[];
  plantas?: string[]; // imagens da planta da unidade (duplex pode ter 2: inferior e superior)
  // 'privado' = anúncio do nosso portfólio que o proprietário não autorizou publicar:
  // fica fora do feed, mostra só um resumo e o anúncio completo só pelo link privado.
  visibilidade?: 'publico' | 'privado';
  cep?: string;
  logradouro?: string;
  bairro?: string;
  cidade?: string;
  uf?: string;
  condominio?: string;
  isTipologia?: boolean;
  // novos (set/2026): área do lote (casa), valores mensais e campos só da equipe
  areaLote?: number;
  areaTotal?: number;
  valorCondominio?: number;
  iptuMensal?: number;
  complemento?: string; // nº da unidade/apto: nunca aparece no site
  unidade?: string; // nº do apto/sala (só equipe): vai na mensagem ao proprietário
  quadra?: string; // casa/lote (só equipe)
  lote?: string;
  obsInterna?: string; // observação só do painel
  proprietarios?: { proprietarioId: string; principal: boolean }[]; // undefined = não mexe
  corretorResponsavel?: string; // e-mail: admin/analista escolhe quem aparece no anúncio
};
export type PropertyFields = Omit<CreatePropertyInput, 'id' | 'corretorEmail' | 'isTipologia'>;

// Aceita só fotos do nosso próprio armazenamento (R2) — nunca link de terceiros
function sanitizePhotos(photos: string[] | undefined): string[] {
  const base = r2PublicBase();
  return (photos ?? [])
    .filter((u) => typeof u === 'string')
    .map(cleanPhotoUrl)
    .filter((u) => /^https:\/\//.test(u) && (!base || u.startsWith(`${base}/`)))
    .slice(0, 60);
}

const clean = (v?: string | null) => (v && v.trim() ? v.trim() : null);

function propertyValues(input: PropertyFields) {
  return [
    input.titulo ? formatTitulo(input.titulo) : null,
    input.tipoUnidade,
    input.finalidade,
    input.deliveryDate && /^\d{4}-\d{2}$/.test(input.deliveryDate) ? `${input.deliveryDate}-01` : null, // vazio = "----"
    input.priceValue,
    input.pricePeriod,
    input.location,
    input.quartos ?? null,
    input.vagas ?? null,
    input.banheiros ?? null,
    input.escaninhos ?? null,
    input.area ?? null,
    input.video,
    videoSeguro(input.videoUrl),
    input.aceitaTemporada,
    input.description,
    JSON.stringify(input.amenities),
    input.empreendimentoId ?? null,
    JSON.stringify(sanitizePhotos(input.photos)),
    clean(input.cep?.replace(/\D/g, '')),
    clean(input.logradouro),
    clean(input.bairro),
    clean(input.cidade),
    clean(input.uf?.toUpperCase()),
    clean(input.condominio ? formatTitulo(input.condominio) : undefined),
    !!input.videoVertical,
    JSON.stringify(sanitizePhotos(input.plantas)),
    input.visibilidade === 'privado' ? 'privado' : 'publico',
    input.areaLote && input.areaLote > 0 ? input.areaLote : null,
    input.valorCondominio && input.valorCondominio > 0 ? input.valorCondominio : null,
    input.iptuMensal && input.iptuMensal > 0 ? input.iptuMensal : null,
    clean(input.complemento?.slice(0, 120)),
    clean(input.obsInterna?.slice(0, 4000)),
    input.areaTotal && input.areaTotal > 0 ? input.areaTotal : null,
    clean(input.unidade?.slice(0, 30)),
    clean(input.quadra?.slice(0, 20)),
    clean(input.lote?.slice(0, 20))
  ];
}
const PROPERTY_COLS =
  'titulo, tipo_unidade, finalidade, delivery_date, price_value, price_period, location, quartos, vagas, banheiros, escaninhos, area, video, video_url, aceita_temporada, description, amenities, empreendimento_id, photos, cep, logradouro, bairro, cidade, uf, condominio, video_vertical, plantas, visibilidade, area_lote, valor_condominio, iptu_mensal, complemento, obs_interna, area_total, unidade, quadra, lote';
const PROPERTY_CASTS = ['', '', '', '::date', '', '', '', '', '', '', '', '', '', '', '', '', '::jsonb', '', '::jsonb', '', '', '', '', '', '', '', '::jsonb', '', '', '', '', '', '', '', '', '', ''];

/** Corretor responsável: admin/analista pode escolher alguém da equipe; os demais ficam como responsáveis */
async function responsavel(staff: StaffSessionPayload, escolhido?: string): Promise<string> {
  if (!escolhido || !veTudo(staff.role)) return staff.email;
  const r = await query<{ email: string }>('select email from staff_users where lower(email) = lower($1)', [escolhido]);
  return r[0]?.email ?? staff.email;
}

export async function createProperty(input: CreatePropertyInput): Promise<void> {
  const staff = await requireStaff();
  const values = propertyValues(input);
  const placeholders = values.map((_, i) => `$${i + 4}${PROPERTY_CASTS[i]}`).join(',');
  await query(
    `insert into properties (id, corretor_email, is_tipologia, match_score, ${PROPERTY_COLS}) values ($1, $2, $3, 50, ${placeholders})`,
    [input.id, await responsavel(staff, input.corretorResponsavel), !!input.isTipologia, ...values]
  );
  if (input.proprietarios) await gravarProprietariosDoImovel(input.id, input.proprietarios);
  if (!input.isTipologia) await avisarInteressados(input.id).catch((err) => console.error('Aviso a interessados falhou', err));
  if (!input.isTipologia) await miniaturaDe('properties', input.id).catch(() => {});
}

export async function updateProperty(id: string, input: PropertyFields): Promise<void> {
  const staff = await requireStaff();
  await assertCanEdit('properties', id, staff);
  const values = propertyValues(input);
  const sets = PROPERTY_COLS.split(', ')
    .map((col, i) => `${col} = $${i + 2}${PROPERTY_CASTS[i]}`)
    .join(', ');
  await query(`update properties set ${sets} where id = $1`, [id, ...values]);
  if (input.corretorResponsavel && veTudo(staff.role)) await query('update properties set corretor_email = $2 where id = $1', [id, await responsavel(staff, input.corretorResponsavel)]);
  if (input.proprietarios) await gravarProprietariosDoImovel(id, input.proprietarios);
  await miniaturaDe('properties', id).catch(() => {});
}

// Nada se perde: antes de sair do ar (excluído ou vendido), o anúncio vai para
// o histórico — base das médias de mercado e do preço do m² por bairro.
async function arquivarNoHistorico(id: string, motivo: 'excluido' | 'vendido', valorVenda?: number | null) {
  await query(
    `insert into imoveis_historico (property_id, motivo, titulo, tipo_unidade, finalidade, price_value, valor_venda, area, quartos, vagas,
        bairro, cidade, uf, condominio, empreendimento_id, delivery_date, visibilidade, corretor_email, anunciado_em, dados)
     select p.id, $2, p.titulo, p.tipo_unidade, p.finalidade, p.price_value, $3, p.area, p.quartos, p.vagas,
        p.bairro, p.cidade, p.uf, coalesce(d.name, p.condominio), p.empreendimento_id, p.delivery_date, p.visibilidade, p.corretor_email, p.created_at, to_jsonb(p)
       from properties p left join developments d on d.id = p.empreendimento_id
      where p.id = $1 and p.is_tipologia = false`,
    [id, motivo, valorVenda && valorVenda > 0 ? valorVenda : null]
  );
}

export async function deleteProperty(id: string): Promise<void> {
  const staff = await requireStaff();
  await assertCanEdit('properties', id, staff);
  const v = await query<{ vendido_em: string | null }>('select vendido_em from properties where id = $1', [id]);
  if (!v[0]?.vendido_em) await arquivarNoHistorico(id, 'excluido'); // vendido já está no histórico
  await query('delete from favorites where property_id = $1', [id]).catch(() => {});
  await query('delete from properties where id = $1', [id]);
}

// Só anúncio avulso pode ser marcado como vendido. Vai para o histórico na hora
// (conta no Mercado) e CONTINUA no site com a tag VENDIDO (gera escassez/urgência):
// - feed inicial, sem filtro: aparece só nos primeiros 15 dias depois da venda;
// - buscas e filtros, página do condomínio/empreendimento, relacionados e páginas de
//   bairro: aparece sempre, depois dos disponíveis;
// - a página do próprio anúncio continua no ar (com VENDIDO).
// Anúncio privado vendido continua privado (nunca aparece para o público).
const DIAS_VENDIDO_NO_FEED = 15;

// Link de vídeo: só https de YouTube, Instagram, TikTok ou Vimeo (nada de "javascript:")
function videoSeguro(url?: string | null): string | null {
  const u = String(url ?? '').trim();
  return /^https:\/\/([a-z0-9-]+\.)*(youtube\.com|youtu\.be|instagram\.com|tiktok\.com|vimeo\.com)\//i.test(u) ? u.slice(0, 400) : null;
}
export async function marcarComoVendido(id: string, valorVenda?: number): Promise<void> {
  const staff = await requireStaff();
  await assertCanEdit('properties', id, staff);
  const r = await query<{ is_tipologia: boolean; visibilidade: string; vendido_em: string | null }>('select is_tipologia, visibilidade, vendido_em from properties where id = $1', [id]);
  if (!r[0] || r[0].is_tipologia) throw new Error('Só anúncio avulso pode ser marcado como vendido.');
  if (r[0].vendido_em) return;
  await arquivarNoHistorico(id, 'vendido', valorVenda ?? null);
  await query('update properties set vendido_em = now() where id = $1', [id]);
}


// ---------------- Anúncios reservados (privados), mascarados ----------------
export type AnuncioOculto = {
  id: string;
  tipoUnidade: TipoUnidade;
  finalidade: 'venda' | 'aluguel';
  bairro: string | null;
  cidade: string | null;
  quartos: number | null;
  vagas: number | null;
  area: number | null;
  preco: number | null;
  precoM2: number | null;
  condominio?: string | null;
  descricao?: string | null; // só na página do anúncio (vai para o Google)
};

function mascarar(r: PropertyRow, comCondominio = false): AnuncioOculto {
  const area = r.area != null ? Number(r.area) : null;
  const preco = Number(r.price_value) || null;
  return {
    id: r.id,
    tipoUnidade: r.tipo_unidade as TipoUnidade,
    finalidade: r.finalidade,
    bairro: r.bairro ?? null,
    cidade: r.cidade ?? null,
    quartos: r.quartos ?? null,
    vagas: r.vagas ?? null,
    area,
    preco,
    precoM2: preco && area && r.finalidade === 'venda' ? Math.round(preco / area) : null,
    condominio: comCondominio ? (r.condominio ? formatTitulo(r.condominio) : null) : undefined
  };
}

/** Resumos dos anúncios privados que atendem a mesma busca do feed */
export async function getAnunciosOcultos(filters: FilterState): Promise<AnuncioOculto[]> {
  const { items } = await feedInterno(0, filters, true);
  const ids = items.filter((i) => i.kind === 'imovel').map((i) => (i as { property: { id: string } }).property.id);
  if (!ids.length) return [];
  const rows = await query<PropertyRow>('select * from properties where id = any($1::text[])', [ids]);
  const map = new Map(rows.map((r) => [r.id, r]));
  return ids.map((id) => map.get(id)).filter(Boolean).slice(0, 12).map((r) => mascarar(r!));
}

/** Privados de um condomínio (página do condomínio) */
export async function getOcultosDoCondominio(developmentId: string, nome: string, cidade?: string | null): Promise<AnuncioOculto[]> {
  const rows = await query<PropertyRow>(
    `select * from properties
      where is_tipologia = false and visibilidade = 'privado' and vendido_em is null
        and (empreendimento_id = $1 or (${norm('condominio')} = ${norm('$2::text')} and ${norm("coalesce(cidade, '')")} = ${norm("coalesce($3::text, '')")}))
      order by created_at desc limit 12`,
    [developmentId, nome, cidade ?? null]
  );
  return rows.map((r) => mascarar(r, true));
}

/** Resumo para a página de um anúncio privado (sem título, fotos ou descrição) */
export async function getResumoOculto(id: string): Promise<AnuncioOculto | null> {
  const rows = await query<PropertyRow>("select * from properties where id = $1 and visibilidade = 'privado'", [id]);
  if (!rows[0]) return null;
  // descrição vai junto (aparece no Google), sem telefones, e-mails e links
  const descricao = String(rows[0].description ?? '')
    .replace(/https?:\/\/\S+/gi, '')
    .replace(/\S+@\S+\.\S+/g, '')
    .replace(/(\(?\d{2}\)?\s?)?9?\d{4}[-\s.]?\d{4}/g, '')
    .trim();
  return { ...mascarar(rows[0], true), descricao: descricao || null };
}

// Dados crus para preencher o formulário de edição
export type PropertyEditData = PropertyFields & { id: string; corretorEmail: string | null };

export async function getPropertyForEdit(id: string): Promise<PropertyEditData | null> {
  const staff = await requireStaff();
  await assertCanEdit('properties', id, staff);
  const rows = await query<PropertyRow & { price_value: string; delivery_date: string | Date | null }>('select * from properties where id = $1', [id]);
  const r = rows[0];
  if (!r) return null;
  const d = !r.delivery_date ? '' : r.delivery_date instanceof Date ? r.delivery_date.toISOString() : String(r.delivery_date);
  return {
    id: r.id,
    corretorEmail: r.corretor_email,
    titulo: r.titulo ?? undefined,
    tipoUnidade: r.tipo_unidade as TipoUnidade,
    finalidade: r.finalidade,
    deliveryDate: d.slice(0, 7),
    priceValue: Number(r.price_value) || 0,
    pricePeriod: r.price_period,
    location: r.location,
    quartos: r.quartos ?? undefined,
    vagas: r.vagas ?? undefined,
    banheiros: r.banheiros ?? undefined,
    escaninhos: r.escaninhos ?? undefined,
    area: r.area != null ? Number(r.area) : undefined,
    video: r.video,
    videoUrl: r.video_url ?? undefined,
    videoVertical: !!r.video_vertical,
    aceitaTemporada: r.aceita_temporada,
    description: r.description,
    amenities: toStringArray(r.amenities),
    empreendimentoId: r.empreendimento_id ?? undefined,
    photos: toStringArray(r.photos),
    plantas: toStringArray(r.plantas),
    visibilidade: r.visibilidade === 'privado' ? 'privado' : 'publico',
    cep: r.cep ?? undefined,
    logradouro: r.logradouro ?? undefined,
    bairro: r.bairro ?? undefined,
    cidade: r.cidade ?? undefined,
    uf: r.uf ?? undefined,
    condominio: r.condominio ?? undefined,
    areaLote: r.area_lote != null ? Number(r.area_lote) : undefined,
    valorCondominio: r.valor_condominio != null ? Number(r.valor_condominio) : undefined,
    iptuMensal: r.iptu_mensal != null ? Number(r.iptu_mensal) : undefined,
    complemento: r.complemento ?? undefined,
    unidade: r.unidade ?? undefined,
    quadra: r.quadra ?? undefined,
    lote: r.lote ?? undefined,
    obsInterna: r.obs_interna ?? undefined,
    areaTotal: r.area_total != null ? Number(r.area_total) : undefined
  };
}

// ---------------- Condomínios / empreendimentos ----------------
export type DevelopmentStatus = 'rascunho' | 'publicado';

export type DevelopmentFields = {
  name: string;
  location: string;
  deliveryDate?: string; // "AAAA-MM" — obrigatório só para publicar
  description: string;
  tipo: 'vertical' | 'horizontal';
  pavimentos?: number;
  areaTerreno?: string;
  amenities: string[];
  aceitaTemporada: boolean;
  videoUrl?: string;
  videoVertical?: boolean;
  heroHeight?: number;
  photos?: string[];
  tiposUnidade?: TipoUnidade[];
  quartosOpcoes?: number[];
  cep?: string;
  logradouro?: string;
  bairro?: string;
  cidade?: string;
  uf?: string;
  status?: DevelopmentStatus;
  // Concepção (construtoras/incorporadoras). undefined = não mexe (importações)
  empresas?: EmpresaNaConcepcao[];
};
export type CreateDevelopmentInput = DevelopmentFields & { id: string; corretorEmail?: string };

// O que falta para um condomínio poder ser publicado (vazio = pode publicar)
export async function pendenciasParaPublicar(f: DevelopmentFields, papel?: string): Promise<string[]> {
  const faltando: string[] = [];
  if (!f.name?.trim()) faltando.push('nome');
  if (!f.bairro?.trim() || !f.cidade?.trim()) faltando.push('endereço (bairro e cidade)');
  // Breve lançamento, lançamento, obras, pronto novo e seminovo: quem não é
  // administrador precisa informar a Concepção (construtora/incorporadora).
  if (f.empresas && !f.empresas.length && papel && papel !== 'admin' && f.deliveryDate && FASES_EXIGEM_CONCEPCAO.includes(getStatusBucket(f.deliveryDate)))
    faltando.push('Concepção (construtora e/ou incorporadora)');
  // Narrativa, tipos, fotos e lazer são opcionais — dá para publicar e completar depois
  return faltando;
}

function developmentValues(input: DevelopmentFields) {
  return [
    formatTitulo(input.name),
    input.location,
    input.deliveryDate ? `${input.deliveryDate}-01` : null,
    input.description,
    input.tipo,
    input.pavimentos ?? null,
    input.areaTerreno ?? null,
    JSON.stringify(input.amenities),
    input.aceitaTemporada,
    input.heroHeight ?? 300,
    videoSeguro(input.videoUrl),
    JSON.stringify(sanitizePhotos(input.photos)),
    JSON.stringify(Array.from(new Set((input.tiposUnidade ?? []).filter((t) => t in TIPO_UNIDADE_LABEL)))),
    JSON.stringify(Array.from(new Set((input.quartosOpcoes ?? []).filter((n) => Number.isInteger(n) && n > 0 && n < 20))).sort((a, b) => a - b)),
    clean(input.cep?.replace(/\D/g, '')),
    clean(input.logradouro),
    clean(input.bairro),
    clean(input.cidade),
    clean(input.uf?.toUpperCase()),
    input.status === 'rascunho' ? 'rascunho' : 'publicado',
    !!input.videoVertical
  ];
}
const DEV_COLS =
  'name, location, delivery_date, description, tipo, pavimentos, area_terreno, amenities, aceita_temporada, hero_height, video_url, photos, tipos_unidade, quartos_opcoes, cep, logradouro, bairro, cidade, uf, status, video_vertical';
const DEV_CASTS = ['', '', '::date', '', '', '', '', '::jsonb', '', '', '', '::jsonb', '::jsonb', '::jsonb', '', '', '', '', '', '', ''];

export type CondoDuplicado = { id: string; name: string; bairro: string | null };
export async function createDevelopment(
  input: CreateDevelopmentInput
): Promise<{ ok: true } | { ok: false; faltando: string[]; duplicado?: CondoDuplicado }> {
  const staff = await requireStaff();
  // Não deixa cadastrar de novo um condomínio que já existe (mesmo nome + mesmo CEP ou bairro)
  const existentes = await query<{ id: string; name: string; cep: string | null; bairro: string | null; cidade: string | null }>(
    'select id, name, cep, bairro, cidade from developments'
  );
  const dup = existentes.find((e) =>
    mesmoCondominio({ nome: e.name, cep: e.cep, bairro: e.bairro, cidade: e.cidade }, { nome: input.name, cep: input.cep, bairro: input.bairro, cidade: input.cidade })
  );
  if (dup) return { ok: false, faltando: [], duplicado: { id: dup.id, name: dup.name, bairro: dup.bairro } };
  if (input.status !== 'rascunho') {
    const faltando = await pendenciasParaPublicar(input, staff.role);
    if (faltando.length) return { ok: false, faltando };
  }
  const values = developmentValues(input);
  const placeholders = values.map((_, i) => `$${i + 3}${DEV_CASTS[i]}`).join(',');
  await query(`insert into developments (id, corretor_email, ${DEV_COLS}) values ($1, $2, ${placeholders})`, [input.id, staff.email, ...values]);
  if (input.empresas) await gravarConcepcao(input.id, input.empresas);
  await miniaturaDe('developments', input.id).catch(() => {});
  return { ok: true };
}

export async function updateDevelopment(id: string, input: DevelopmentFields): Promise<{ ok: true } | { ok: false; faltando: string[] }> {
  const staff = await requireStaff();
  await assertCanEdit('developments', id, staff);
  if (input.status !== 'rascunho') {
    const faltando = await pendenciasParaPublicar(input, staff.role);
    if (faltando.length) return { ok: false, faltando };
  }
  if (input.empresas) await gravarConcepcao(id, input.empresas);
  const values = developmentValues(input);
  const sets = DEV_COLS.split(', ')
    .map((col, i) => `${col} = $${i + 2}${DEV_CASTS[i]}`)
    .join(', ');
  await query(`update developments set ${sets} where id = $1`, [id, ...values]);
  // As tipologias da tabela de vendas acompanham o endereço, as fotos e a entrega do condomínio
  if (input.deliveryDate) {
    await query(
      `update properties set location = $2, bairro = $3, cidade = $4, uf = $5, cep = $6, condominio = $7, delivery_date = $8::date, photos = $9::jsonb
        where empreendimento_id = $1 and is_tipologia = true`,
      [id, input.location, clean(input.bairro), clean(input.cidade), clean(input.uf), clean(input.cep?.replace(/\D/g, '')), input.name, `${input.deliveryDate}-01`, JSON.stringify(sanitizePhotos(input.photos))]
    );
  }
  await miniaturaDe('developments', id).catch(() => {});
  return { ok: true };
}

// Tipologias da tabela de vendas: cria as novas, atualiza as existentes e remove as que saíram da lista
export type TipologiaInput = { id?: string; tipoUnidade: TipoUnidade; quartos?: number; vagas?: number; area?: number; priceValue: number; plantas?: string[] };

export async function saveTipologias(developmentId: string, tipologias: TipologiaInput[]): Promise<void> {
  const staff = await requireStaff();
  await assertCanEdit('developments', developmentId, staff);
  const devRows = await query<DevelopmentRow>('select * from developments where id = $1', [developmentId]);
  const dev = devRows[0];
  if (!dev) throw new Error('Condomínio não encontrado.');
  const existing = await query<{ id: string }>('select id from properties where empreendimento_id = $1 and is_tipologia = true', [developmentId]);
  const keep = new Set(tipologias.map((t) => t.id).filter(Boolean) as string[]);
  for (const e of existing) if (!keep.has(e.id)) await query('delete from properties where id = $1 and is_tipologia = true', [e.id]);

  const delivery = dev.delivery_date ? (dev.delivery_date instanceof Date ? dev.delivery_date.toISOString() : String(dev.delivery_date)).slice(0, 7) : '';
  for (const [i, t] of tipologias.entries()) {
    const fields: PropertyFields = {
      tipoUnidade: t.tipoUnidade,
      finalidade: 'venda',
      deliveryDate: delivery,
      priceValue: t.priceValue || 0,
      pricePeriod: 'unico',
      location: dev.location,
      quartos: t.quartos,
      vagas: t.vagas,
      area: t.area,
      video: false,
      aceitaTemporada: dev.aceita_temporada,
      description: `${TIPO_UNIDADE_LABEL[t.tipoUnidade]}${t.quartos ? ` de ${t.quartos} quartos` : ''}${t.area ? `, ${t.area} m²` : ''} no ${dev.name}, em ${dev.location}.`,
      amenities: toStringArray(dev.amenities),
      empreendimentoId: developmentId,
      photos: toStringArray(dev.photos),
      plantas: t.plantas ?? [],
      cep: dev.cep ?? undefined,
      bairro: dev.bairro ?? undefined,
      cidade: dev.cidade ?? undefined,
      uf: dev.uf ?? undefined,
      condominio: dev.name
    };
    if (t.id && existing.some((e) => e.id === t.id)) {
      const values = propertyValues(fields);
      const sets = PROPERTY_COLS.split(', ')
        .map((col, k) => `${col} = $${k + 2}${PROPERTY_CASTS[k]}`)
        .join(', ');
      await query(`update properties set ${sets} where id = $1 and is_tipologia = true`, [t.id, ...values]);
    } else {
      await createProperty({ ...fields, id: `${developmentId}-tip-${Date.now()}-${i}`, isTipologia: true });
    }
  }
}

export type DevelopmentEditData = DevelopmentFields & { id: string; tipologias: (TipologiaInput & { id: string })[] };

export async function getDevelopmentForEdit(id: string): Promise<DevelopmentEditData | null> {
  const staff = await requireStaff();
  await assertCanEdit('developments', id, staff);
  const rows = await query<DevelopmentRow>('select * from developments where id = $1', [id]);
  const d = rows[0];
  if (!d) return null;
  const tips = await query<{ id: string; tipo_unidade: string; quartos: number | null; vagas: number | null; area: string | null; price_value: string; plantas: unknown }>(
    'select id, tipo_unidade, quartos, vagas, area, price_value, plantas from properties where empreendimento_id = $1 and is_tipologia = true order by area asc nulls last',
    [id]
  );
  const dd = d.delivery_date ? (d.delivery_date instanceof Date ? d.delivery_date.toISOString() : String(d.delivery_date)).slice(0, 7) : undefined;
  return {
    id: d.id,
    name: d.name,
    location: d.location,
    deliveryDate: dd,
    description: d.description,
    tipo: d.tipo,
    pavimentos: d.pavimentos ?? undefined,
    areaTerreno: d.area_terreno ?? undefined,
    amenities: toStringArray(d.amenities),
    aceitaTemporada: d.aceita_temporada,
    videoUrl: d.video_url ?? undefined,
    videoVertical: !!d.video_vertical,
    heroHeight: d.hero_height,
    photos: toStringArray(d.photos),
    tiposUnidade: toStringArray(d.tipos_unidade) as TipoUnidade[],
    quartosOpcoes: (Array.isArray(d.quartos_opcoes) ? (d.quartos_opcoes as unknown[]) : []).map(Number).filter((n) => n > 0),
    cep: d.cep ?? undefined,
    logradouro: d.logradouro ?? undefined,
    bairro: d.bairro ?? undefined,
    cidade: d.cidade ?? undefined,
    uf: d.uf ?? undefined,
    status: d.status === 'rascunho' ? 'rascunho' : 'publicado',
    tipologias: tips.map((t) => ({
      id: t.id,
      tipoUnidade: t.tipo_unidade as TipoUnidade,
      quartos: t.quartos ?? undefined,
      vagas: t.vagas ?? undefined,
      area: t.area != null ? Number(t.area) : undefined,
      priceValue: Number(t.price_value) || 0,
      plantas: toStringArray(t.plantas)
    }))
  };
}

// Lista leve para o seletor de condomínio no cadastro e para o painel
export type CondominioResumo = {
  id: string;
  name: string;
  bairro: string | null;
  cidade: string | null;
  uf: string | null;
  cep: string | null;
  logradouro: string | null;
  status: DevelopmentStatus;
  amenities: string[];
  deliveryDate: string | null;
  anuncios: number;
  tipologias: number;
  temFotos: boolean;
  corretorEmail: string | null;
  criadoEm?: string | null;
};

export async function listCondominios(): Promise<CondominioResumo[]> {
  await requireStaff();
  const rows = await query<DevelopmentRow & { anuncios: string; tipologias: string }>(
    `select d.*,
            (select count(*) from properties p where p.empreendimento_id = d.id and p.is_tipologia = false) as anuncios,
            (select count(*) from properties p where p.empreendimento_id = d.id and p.is_tipologia = true) as tipologias
       from developments d order by d.name`
  );
  return rows.map((d) => ({
    id: d.id,
    name: formatTitulo(d.name),
    bairro: d.bairro ?? null,
    cidade: d.cidade ?? null,
    uf: d.uf ?? null,
    cep: d.cep ?? null,
    logradouro: d.logradouro ?? null,
    status: d.status === 'rascunho' ? 'rascunho' : 'publicado',
    amenities: toStringArray(d.amenities),
    deliveryDate: d.delivery_date ? (d.delivery_date instanceof Date ? d.delivery_date.toISOString() : String(d.delivery_date)).slice(0, 7) : null,
    anuncios: Number(d.anuncios) || 0,
    tipologias: Number(d.tipologias) || 0,
    temFotos: toStringArray(d.photos).length > 0,
    corretorEmail: d.corretor_email,
    criadoEm: (d as unknown as { created_at?: Date | string | null }).created_at ? new Date((d as unknown as { created_at: Date | string }).created_at).toISOString() : null
  }));
}

// ---------------- Interessados em condomínios ("Registre seu interesse") ----------------
export type InteresseInput = {
  developmentId?: string;
  condominio: string;
  nome: string;
  email?: string;
  telefone?: string;
  finalidade: 'venda' | 'aluguel';
  areaMin?: number;
  areaMax?: number;
  valorMax?: number;
  quartos?: number;
  mensagem?: string;
  aceitaContato: boolean;
};

export async function registrarInteresse(input: InteresseInput): Promise<{ ok: boolean; erro?: string }> {
  const nome = (input.nome ?? '').trim().slice(0, 120);
  const email = (input.email ?? '').trim().toLowerCase().slice(0, 160);
  const telefone = (input.telefone ?? '').replace(/[^\d+]/g, '').slice(0, 20);
  if (nome.length < 2) return { ok: false, erro: 'Informe seu nome.' };
  if (!email && telefone.length < 10) return { ok: false, erro: 'Informe um e-mail ou um WhatsApp com DDD.' };
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, erro: 'Confira o e-mail digitado.' };
  if (!input.aceitaContato) return { ok: false, erro: 'Para avisarmos você, é preciso autorizar o contato.' };
  const condominio = formatTitulo((input.condominio ?? '').slice(0, 160));
  const devId = input.developmentId && /^[\w-]{1,80}$/.test(input.developmentId) ? input.developmentId : null;

  // Contra robôs: no máximo 10 formulários por hora do mesmo endereço
  const ip = ipDoVisitante();
  if (!(await dentroDoLimite(`lead:${ip}`, 10, 60))) return { ok: false, erro: 'Muitas mensagens em pouco tempo. Tente de novo mais tarde.' };
  await registrarUso(`lead:${ip}`);

  // Evita cadastro repetido em sequência (mesma pessoa, mesmo condomínio, últimos 10 min)
  const dup = await query<{ id: string }>(
    `select id from interest_leads where condominio = $1 and ((email is not null and email = $2) or (telefone is not null and telefone = $3))
       and created_at > now() - interval '10 minutes' limit 1`,
    [condominio, email || null, telefone || null]
  );
  if (dup[0]) return { ok: true };

  const num = (n?: number) => (typeof n === 'number' && Number.isFinite(n) && n > 0 ? n : null);
  await query(
    `insert into interest_leads (development_id, condominio, nome, email, telefone, finalidade, area_min, area_max, valor_max, quartos, mensagem, aceita_contato)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
    [devId, condominio, nome, email || null, telefone || null, input.finalidade === 'aluguel' ? 'aluguel' : 'venda', num(input.areaMin), num(input.areaMax), num(input.valorMax), num(input.quartos), (input.mensagem ?? '').trim().slice(0, 1000) || null, true]
  );

  // Aviso para a equipe (se o e-mail estiver configurado)
  const equipe = process.env.EMAIL_EQUIPE;
  if (equipe) {
    const linha = (rotulo: string, valor?: string | number | null) =>
      valor ? `<tr><td style="padding:4px 12px 4px 0;color:#6b6f76">${rotulo}</td><td style="padding:4px 0"><strong>${escapeHtml(String(valor))}</strong></td></tr>` : '';
    const brl = (n?: number) => (n ? n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }) : null);
    await enviarEmail(
      equipe,
      `Novo interessado no ${condominio}`,
      emailLayout(
        `Novo interessado no ${escapeHtml(condominio)}`,
        `<table style="font-size:14px">${linha('Nome', nome)}${linha('WhatsApp', telefone)}${linha('E-mail', email)}${linha('Quer', input.finalidade === 'aluguel' ? 'Alugar' : 'Comprar')}${linha('Metragem', input.areaMin || input.areaMax ? `${input.areaMin ?? '?'} a ${input.areaMax ?? '?'} m²` : null)}${linha('Até', brl(input.valorMax))}${linha('Quartos', input.quartos)}${linha('Mensagem', input.mensagem)}</table>
         <p style="font-size:13px;color:#6b6f76;margin-top:16px">Veja todos em Painel → Interessados.</p>`
      )
    );
  }
  return { ok: true };
}

export type InteresseLead = {
  id: string;
  developmentId: string | null;
  condominio: string;
  nome: string;
  email: string | null;
  telefone: string | null;
  finalidade: 'venda' | 'aluguel';
  areaMin: number | null;
  areaMax: number | null;
  valorMax: number | null;
  quartos: number | null;
  mensagem: string | null;
  status: 'novo' | 'contatado' | 'descartado';
  descadastrado: boolean;
  ultimoAviso: string | null;
  criadoEm: string;
};

export async function listInteresses(): Promise<InteresseLead[]> {
  await requireStaff();
  const rows = await query<Record<string, unknown>>('select * from interest_leads order by created_at desc limit 500');
  const n = (v: unknown) => (v == null ? null : Number(v));
  const d = (v: unknown) => (v == null ? null : new Date(v as string).toISOString());
  return rows.map((r) => ({
    id: String(r.id),
    developmentId: (r.development_id as string) ?? null,
    condominio: String(r.condominio),
    nome: String(r.nome),
    email: (r.email as string) ?? null,
    telefone: (r.telefone as string) ?? null,
    finalidade: r.finalidade === 'aluguel' ? 'aluguel' : 'venda',
    areaMin: n(r.area_min),
    areaMax: n(r.area_max),
    valorMax: n(r.valor_max),
    quartos: n(r.quartos),
    mensagem: (r.mensagem as string) ?? null,
    status: (r.status as InteresseLead['status']) ?? 'novo',
    descadastrado: !!r.descadastrado_em,
    ultimoAviso: d(r.ultimo_aviso_em),
    criadoEm: d(r.created_at) ?? ''
  }));
}

export async function updateInteresseStatus(id: string, status: InteresseLead['status']): Promise<void> {
  await requireStaff();
  if (!['novo', 'contatado', 'descartado'].includes(status)) throw new Error('Status inválido.');
  await query('update interest_leads set status = $1 where id = $2::uuid', [status, id]);
}

// Quando um imóvel entra num condomínio, avisa por e-mail quem registrou interesse nele
async function avisarInteressados(propertyId: string): Promise<void> {
  if (!emailConfigurado()) return;
  const props = await query<PropertyRow>("select * from properties where id = $1 and is_tipologia = false and visibilidade = 'publico'", [propertyId]);
  const p = props[0];
  if (!p) return;
  const devRows = p.empreendimento_id ? await query<{ name: string }>('select name from developments where id = $1', [p.empreendimento_id]) : [];
  const nomeCondo = devRows[0]?.name ?? p.condominio;
  if (!nomeCondo && !p.empreendimento_id) return;
  const leads = await query<{ id: string; nome: string; email: string; unsubscribe_token: string; valor_max: string | null }>(
    `select id, nome, email, unsubscribe_token, valor_max from interest_leads
      where email is not null and aceita_contato and descadastrado_em is null and finalidade = $1
        and (($2::text is not null and development_id = $2) or ($3::text is not null and ${norm('condominio')} = ${norm('$3::text')}))`,
    [p.finalidade, p.empreendimento_id, nomeCondo ?? null]
  );
  if (!leads.length) return;
  const imovel = mapPropertyRow(p);
  const titulo = imovel.titulo || `${TIPO_UNIDADE_LABEL[imovel.tipoUnidade]} em ${imovel.location}`;
  const link = `${SITE_URL}${urlImovel(p)}`;
  for (const l of leads) {
    const preco = Number(p.price_value);
    if (l.valor_max && preco > Number(l.valor_max) * 1.35) continue; // bem acima do que a pessoa quer investir
    const ok = await enviarEmail(
      l.email,
      `Novo imóvel no ${formatTitulo(nomeCondo ?? '')}`,
      emailLayout(
        `Surgiu um imóvel no ${escapeHtml(formatTitulo(nomeCondo ?? ''))}`,
        `<p style="font-size:15px">Olá, ${escapeHtml(l.nome.split(' ')[0])}! Você pediu para ser avisado(a), e acabou de entrar:</p>
         <p style="font-size:16px"><strong>${escapeHtml(titulo)}</strong><br>${escapeHtml(imovel.price)} · ${escapeHtml(imovel.beds)} · ${escapeHtml(imovel.area)}</p>
         <p><a href="${link}" style="display:inline-block;background:#14161a;color:#fff;text-decoration:none;padding:12px 20px;border-radius:999px;font-weight:bold">Ver o imóvel</a></p>
         <p style="font-size:11px;color:#9aa0a8;margin-top:20px">Não quer mais receber avisos deste condomínio? <a href="${SITE_URL}/api/interesse/cancelar?t=${l.unsubscribe_token}" style="color:#9aa0a8">Cancelar avisos</a></p>`
      )
    );
    if (ok) await query('update interest_leads set ultimo_aviso_em = now() where id = $1::uuid', [l.id]);
  }
}

// ---------------- Login da equipe ----------------
// Contra força bruta: 5 erros por e-mail ou 15 por IP em 15 minutos = bloqueio temporário.
export async function staffLogin(email: string, password: string): Promise<StaffSessionPayload | null | 'bloqueado'> {
  email = String(email ?? '').trim().toLowerCase().slice(0, 200);
  password = String(password ?? '').slice(0, 200);
  const ip = ipDoVisitante();
  const [okEmail, okIp] = await Promise.all([dentroDoLimite(`login-erro:email:${email}`, 5, 15), dentroDoLimite(`login-erro:ip:${ip}`, 15, 15)]);
  if (!okEmail || !okIp) return 'bloqueado';
  const rows = await query<{ email: string; name: string; role: StaffRole; password_hash: string }>(
    'select email, name, role, password_hash from staff_users where lower(email) = $1',
    [email]
  );
  const user = rows[0];
  // compara mesmo sem usuário (tempo de resposta igual — não revela quais e-mails existem)
  const valid = await bcrypt.compare(password, user?.password_hash ?? '$2a$10$0000000000000000000000000000000000000000000000000000a');
  if (!user || !valid) {
    await Promise.all([registrarUso(`login-erro:email:${email}`), registrarUso(`login-erro:ip:${ip}`)]);
    return null;
  }

  const payload: StaffSessionPayload = { email: user.email, name: user.name, role: user.role };
  // O cookie vale em maisnovosimoveis.com e em app.maisnovosimoveis.com (domínio
  // ".maisnovosimoveis.com"): a equipe logada no app também é reconhecida no site
  // (vê rascunhos, anúncios privados e não conta visualização).
  const dominio = dominioDoCookie(headers().get('host'));
  cookies().set(STAFF_COOKIE, signSession(payload), {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
    ...(dominio ? { domain: dominio } : {})
  });
  return payload;
}

export async function staffLogout(): Promise<void> {
  const dominio = dominioDoCookie(headers().get('host'));
  cookies().set(STAFF_COOKIE, '', { httpOnly: true, secure: true, sameSite: 'lax', path: '/', maxAge: 0, ...(dominio ? { domain: dominio } : {}) });
}

export async function getStaffSession(): Promise<StaffSessionPayload | null> {
  return staffAtual();
}

// ---------------- Mercado (histórico) ----------------
// Tudo que já passou pelo portal: anúncios ativos (públicos e privados) +
// histórico (vendidos e excluídos). Base do preço médio do m² por bairro.
export type MercadoBairro = {
  bairro: string;
  cidade: string;
  ativos: number;
  privados: number;
  vendidos: number;
  excluidos: number;
  m2Anuncios: number | null; // média do m² pedido (venda) — todos os anúncios
  m2Vendidos: number | null; // média do m² dos vendidos (valor de venda, se informado)
};
export type MercadoMes = { mes: string; m2Anuncios: number | null; nAnuncios: number; m2Vendidos: number | null; nVendidos: number };

const BASE_MERCADO = `
  select p.bairro, p.cidade, p.tipo_unidade, p.price_value as preco, p.area, p.created_at as data_anuncio, null::timestamptz as data_fim,
         case when p.visibilidade = 'privado' then 'privado' else 'ativo' end as estado
    from properties p where p.is_tipologia = false and p.finalidade = 'venda' and p.vendido_em is null
  union all
  select h.bairro, h.cidade, h.tipo_unidade, coalesce(h.valor_venda, h.price_value), h.area, h.anunciado_em, h.encerrado_em, h.motivo
    from imoveis_historico h where h.finalidade = 'venda'`;

export async function getMercado(tipos?: string[]): Promise<MercadoBairro[]> {
  await requireStaff();
  const filtroTipo = tipos?.length ? 'and tipo_unidade = any($1::text[])' : '';
  const rows = await query<{ bairro: string; cidade: string; ativos: string; privados: string; vendidos: string; excluidos: string; m2a: string | null; m2v: string | null }>(
    `with base as (${BASE_MERCADO})
     select mode() within group (order by bairro) as bairro, mode() within group (order by cidade) as cidade,
            count(*) filter (where estado = 'ativo') as ativos,
            count(*) filter (where estado = 'privado') as privados,
            count(*) filter (where estado = 'vendido') as vendidos,
            count(*) filter (where estado = 'excluido') as excluidos,
            avg(preco / area) filter (where preco > 0 and area > 0) as m2a,
            avg(preco / area) filter (where preco > 0 and area > 0 and estado = 'vendido') as m2v
       from base
      where bairro is not null ${filtroTipo}
      group by ${norm('bairro')}, ${norm("coalesce(cidade, '')")}
      order by count(*) desc limit 200`,
    tipos?.length ? [tipos] : []
  );
  const n = (v: string | null) => (v != null ? Math.round(Number(v)) : null);
  return rows.map((r) => ({
    bairro: r.bairro,
    cidade: r.cidade,
    ativos: Number(r.ativos),
    privados: Number(r.privados),
    vendidos: Number(r.vendidos),
    excluidos: Number(r.excluidos),
    m2Anuncios: n(r.m2a),
    m2Vendidos: n(r.m2v)
  }));
}

export async function getMercadoMensal(bairro: string, cidade: string, tipos?: string[]): Promise<MercadoMes[]> {
  await requireStaff();
  const params: unknown[] = [bairro, cidade];
  const filtroTipo = tipos?.length ? `and tipo_unidade = any($3::text[])` : '';
  if (tipos?.length) params.push(tipos);
  const rows = await query<{ mes: string; m2a: string | null; na: string; m2v: string | null; nv: string }>(
    `with base as (${BASE_MERCADO}),
     sel as (select * from base where ${norm("coalesce(bairro, '')")} = ${norm('$1::text')} and ${norm("coalesce(cidade, '')")} = ${norm('$2::text')} ${filtroTipo}),
     anuncios as (
       select to_char(date_trunc('month', data_anuncio), 'YYYY-MM') as mes, avg(preco / area) as m2, count(*) as n
         from sel where preco > 0 and area > 0 and data_anuncio is not null group by 1
     ),
     vendas as (
       select to_char(date_trunc('month', data_fim), 'YYYY-MM') as mes, avg(preco / area) as m2, count(*) as n
         from sel where estado = 'vendido' and preco > 0 and area > 0 group by 1
     )
     select coalesce(a.mes, v.mes) as mes, a.m2 as m2a, coalesce(a.n, 0) as na, v.m2 as m2v, coalesce(v.n, 0) as nv
       from anuncios a full join vendas v on v.mes = a.mes
      order by 1`,
    params
  );
  return rows.map((r) => ({
    mes: r.mes,
    m2Anuncios: r.m2a != null ? Math.round(Number(r.m2a)) : null,
    nAnuncios: Number(r.na),
    m2Vendidos: r.m2v != null ? Math.round(Number(r.m2v)) : null,
    nVendidos: Number(r.nv)
  }));
}

export type HistoricoLinha = { propertyId: string; motivo: string; titulo: string | null; tipoUnidade: string; preco: number | null; valorVenda: number | null; area: number | null; bairro: string | null; cidade: string | null; condominio: string | null; encerradoEm: string };

export async function listHistorico(): Promise<HistoricoLinha[]> {
  await requireStaff();
  const rows = await query<{ property_id: string; motivo: string; titulo: string | null; tipo_unidade: string; price_value: string | null; valor_venda: string | null; area: string | null; bairro: string | null; cidade: string | null; condominio: string | null; encerrado_em: Date }>(
    'select * from imoveis_historico order by encerrado_em desc limit 300'
  );
  return rows.map((r) => ({
    propertyId: r.property_id,
    motivo: r.motivo,
    titulo: r.titulo,
    tipoUnidade: r.tipo_unidade,
    preco: r.price_value ? Number(r.price_value) : null,
    valorVenda: r.valor_venda ? Number(r.valor_venda) : null,
    area: r.area ? Number(r.area) : null,
    bairro: r.bairro,
    cidade: r.cidade,
    condominio: r.condominio,
    encerradoEm: new Date(r.encerrado_em).toISOString()
  }));
}

// ---------------- Importação de condomínios por planilha ----------------
export type CondoImport = {
  nome: string;
  tipo: 'vertical' | 'horizontal';
  tiposUnidade: TipoUnidade[];
  cep: string;
  uf: string;
  cidade: string;
  bairro: string;
  logradouro: string;
  entrega?: string; // AAAA-MM
  descricao: string;
  pavimentos?: number;
  amenities: string[];
  rascunho?: boolean;
  lat?: number;
  lng?: number;
  videoUrl?: string;
  // Concepção: nome e/ou CNPJ da construtora e da incorporadora
  empresas?: EmpresaPlanilha[];
  quartosOpcoes?: number[];
  metragens?: number[];
};
export type ResultadoImport = { criados: number; atualizados: number; pulados: number; erros: string[]; empresasLigadas?: number };

type Existente = { id: string; name: string; cep: string | null; bairro: string | null; cidade: string | null };
async function carregarExistentes(): Promise<Map<string, Existente[]>> {
  const rows = await query<Existente>('select id, name, cep, bairro, cidade from developments');
  const m = new Map<string, Existente[]>();
  for (const r of rows) {
    const k = chaveNome(r.name);
    m.set(k, [...(m.get(k) ?? []), r]);
  }
  return m;
}
function acharExistente(idx: Map<string, Existente[]>, c: { nome: string; cep: string; bairro: string; cidade: string }): Existente | undefined {
  return (idx.get(chaveNome(c.nome)) ?? []).find((e) => mesmoCondominio({ nome: e.name, cep: e.cep, bairro: e.bairro, cidade: e.cidade }, c));
}

/** Quais linhas já existem no banco (índice das linhas) — para a tela mostrar antes de gravar */
export async function conferirExistentes(lista: { nome: string; cep: string; bairro: string; cidade: string }[]): Promise<number[]> {
  await exigirGestor();
  const idx = await carregarExistentes();
  return lista.map((c, i) => (acharExistente(idx, c) ? i : -1)).filter((i) => i >= 0);
}

/**
 * Grava um lote (até 300 linhas). Já existentes (mesmo nome + mesmo CEP ou mesmo bairro):
 *  - 'pular': não mexe
 *  - 'completar': só preenche o que estiver vazio (entrega, descrição, endereço, pavimentos, lazer, localização)
 */
export async function importarCondominios(lote: CondoImport[], opcoes: { status: 'publicado' | 'rascunho'; existentes: 'pular' | 'completar' }): Promise<ResultadoImport> {
  const staff = await exigirGestor();
  const res: ResultadoImport = { criados: 0, atualizados: 0, pulados: 0, erros: [] };
  const linhas = (lote ?? []).slice(0, 300).filter((c) => c && typeof c.nome === 'string' && c.nome.trim());
  if (!linhas.length) return res;

  const idx = await carregarExistentes();
  const novos: Record<string, unknown>[] = [];
  const atualizar: Record<string, unknown>[] = [];
  const ligar: { id: string; empresas: EmpresaPlanilha[] }[] = [];
  const metragens: { id: string; areas: number[]; quartos: number[]; tipo: string; tipos: string[]; location: string }[] = [];
  const agora = Date.now().toString(36);
  const num = (v: unknown, max: number) => (typeof v === 'number' && Number.isFinite(v) && Math.abs(v) <= max && v !== 0 ? v : null);
  linhas.forEach((c, i) => {
    const nome = formatTitulo(c.nome.trim()).slice(0, 160);
    const bairro = clean(c.bairro)?.slice(0, 120) ?? null;
    const cidade = clean(c.cidade)?.slice(0, 120) ?? null;
    const uf = clean(c.uf?.toUpperCase())?.slice(0, 2) ?? null;
    const cep = clean((c.cep ?? '').replace(/\D/g, ''))?.slice(0, 8) ?? null;
    const entrega = c.entrega && /^\d{4}-\d{2}$/.test(c.entrega) ? `${c.entrega}-01` : null;
    const reg = {
      name: nome,
      location: [bairro, [cidade, uf].filter(Boolean).join('/')].filter(Boolean).join(', '),
      delivery_date: entrega,
      description: (c.descricao ?? '').slice(0, 5000),
      tipo: c.tipo === 'horizontal' ? 'horizontal' : 'vertical',
      pavimentos: c.pavimentos && c.pavimentos > 0 && c.pavimentos < 200 ? Math.round(c.pavimentos) : null,
      amenities: (c.amenities ?? []).filter((a) => typeof a === 'string').slice(0, 30),
      tipos_unidade: Array.from(new Set((c.tiposUnidade ?? []).filter((t) => t in TIPO_UNIDADE_LABEL))),
      quartos_opcoes: (c.quartosOpcoes ?? []).filter((n) => Number.isInteger(n) && n > 0 && n < 20).slice(0, 10),
      cep,
      logradouro: clean(c.logradouro)?.slice(0, 200) ?? null,
      bairro,
      cidade,
      uf,
      lat: num(c.lat, 90),
      lng: num(c.lng, 180),
      video_url: c.videoUrl && /^https:\/\/(www\.)?(youtube\.com|youtu\.be|instagram\.com|vimeo\.com)\//.test(c.videoUrl) ? c.videoUrl.slice(0, 300) : null,
      // Sem bairro/cidade entra como rascunho; sem ano de entrega pode publicar (aparece "----")
      status: opcoes.status === 'publicado' && !c.rascunho && bairro && cidade ? 'publicado' : 'rascunho'
    };
    const existente = acharExistente(idx, { nome, cep: cep ?? '', bairro: bairro ?? '', cidade: cidade ?? '' });
    if (existente) {
      if (opcoes.existentes === 'completar') {
        atualizar.push({ id: existente.id, ...reg });
        if (c.empresas?.length) ligar.push({ id: existente.id, empresas: c.empresas });
        if (c.metragens?.length) metragens.push({ id: existente.id, areas: c.metragens, quartos: c.quartosOpcoes ?? [], tipo: reg.tipo, tipos: reg.tipos_unidade, location: reg.location });
      } else res.pulados++;
      return;
    }
    const id = `condo-p${agora}${i.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    novos.push({ id, ...reg });
    if (c.empresas?.length) ligar.push({ id, empresas: c.empresas });
    if (c.metragens?.length) metragens.push({ id, areas: c.metragens, quartos: c.quartosOpcoes ?? [], tipo: reg.tipo, tipos: reg.tipos_unidade, location: reg.location });
    // evita duplicar dentro do próprio lote
    const k = chaveNome(nome);
    idx.set(k, [...(idx.get(k) ?? []), { id, name: nome, cep, bairro, cidade }]);
  });

  const COLS = `id text, name text, location text, delivery_date date, description text, tipo text, pavimentos int, amenities jsonb,
                tipos_unidade jsonb, quartos_opcoes jsonb, cep text, logradouro text, bairro text, cidade text, uf text, lat double precision, lng double precision,
                video_url text, status text`;
  try {
    if (novos.length) {
      await query(
        `insert into developments (id, corretor_email, name, location, delivery_date, description, tipo, pavimentos, area_terreno, amenities,
            aceita_temporada, hero_height, video_url, photos, tipos_unidade, quartos_opcoes, cep, logradouro, bairro, cidade, uf, status, video_vertical,
            lat, lng, origem)
         select r.id, $2, r.name, r.location, r.delivery_date, r.description, r.tipo, r.pavimentos, null, coalesce(r.amenities, '[]'::jsonb),
            false, 300, r.video_url, '[]'::jsonb, coalesce(r.tipos_unidade, '[]'::jsonb), coalesce(r.quartos_opcoes, '[]'::jsonb), r.cep, r.logradouro, r.bairro, r.cidade, r.uf,
            r.status, false, r.lat, r.lng, 'planilha'
           from jsonb_to_recordset($1::jsonb) as r(${COLS})`,
        [JSON.stringify(novos), staff.email]
      );
      res.criados = novos.length;
    }
    if (atualizar.length) {
      await query(
        `update developments d set
            delivery_date = coalesce(d.delivery_date, r.delivery_date),
            description = case when length(coalesce(trim(d.description), '')) < length(coalesce(r.description, '')) and length(coalesce(trim(d.description), '')) < 60
                               then r.description else d.description end,
            pavimentos = coalesce(d.pavimentos, r.pavimentos),
            amenities = case when jsonb_array_length(coalesce(d.amenities, '[]'::jsonb)) = 0 then coalesce(r.amenities, '[]'::jsonb) else d.amenities end,
            tipos_unidade = case when jsonb_array_length(coalesce(d.tipos_unidade, '[]'::jsonb)) = 0 then coalesce(r.tipos_unidade, '[]'::jsonb) else d.tipos_unidade end,
            quartos_opcoes = case when jsonb_array_length(coalesce(d.quartos_opcoes, '[]'::jsonb)) = 0 then coalesce(r.quartos_opcoes, '[]'::jsonb) else d.quartos_opcoes end,
            cep = coalesce(nullif(d.cep, ''), r.cep),
            logradouro = coalesce(nullif(d.logradouro, ''), r.logradouro),
            bairro = coalesce(nullif(d.bairro, ''), r.bairro),
            cidade = coalesce(nullif(d.cidade, ''), r.cidade),
            uf = coalesce(nullif(d.uf, ''), r.uf),
            lat = coalesce(d.lat, r.lat),
            lng = coalesce(d.lng, r.lng),
            video_url = coalesce(nullif(d.video_url, ''), r.video_url),
            location = case when coalesce(d.location, '') = '' then r.location else d.location end
           from jsonb_to_recordset($1::jsonb) as r(${COLS})
          where d.id = r.id`,
        [JSON.stringify(atualizar)]
      );
      res.atualizados = atualizar.length;
    }
    // Metragens da planilha viram tipologias (sem preço) — só em condomínio que ainda não tem tipologia.
    // Com a mesma quantidade de quartos e metragens, cada metragem ganha o seu nº de quartos.
    const linhasTip: Record<string, unknown>[] = [];
    const semTip = metragens.length
      ? new Set(
          (await query<{ id: string }>(
            'select d.id from developments d where d.id = any($1::text[]) and not exists (select 1 from properties p where p.empreendimento_id = d.id and p.is_tipologia)',
            [metragens.map((m) => m.id)]
          )).map((r) => r.id)
        )
      : new Set<string>();
    for (const m of metragens) {
      if (!semTip.has(m.id)) continue;
      const tipoUn = m.tipos.find((t) => t in TIPO_UNIDADE_LABEL) ?? (m.tipo === 'horizontal' ? 'casa_condominio' : 'apartamento');
      m.areas.slice(0, 12).forEach((area, k) =>
        linhasTip.push({
          id: `tip-${m.id.slice(-12)}-${k}${Math.random().toString(36).slice(2, 6)}`,
          empreendimento_id: m.id,
          area,
          quartos: m.quartos.length === m.areas.length ? m.quartos[k] : null,
          tipo_unidade: tipoUn,
          location: m.location
        })
      );
    }
    if (linhasTip.length) {
      await query(
        `insert into properties (id, corretor_email, is_tipologia, match_score, tipo_unidade, finalidade, price_value, price_period, location, quartos, area,
            video, aceita_temporada, description, amenities, empreendimento_id, photos, plantas, visibilidade)
         select r.id, $2, true, 50, r.tipo_unidade, 'venda', 0, 'unico', r.location, r.quartos, r.area, false, false, '', '[]'::jsonb, r.empreendimento_id,
                '[]'::jsonb, '[]'::jsonb, 'publico'
           from jsonb_to_recordset($1::jsonb) as r(id text, empreendimento_id text, area numeric, quartos int, tipo_unidade text, location text)
         on conflict (id) do nothing`,
        [JSON.stringify(linhasTip), staff.email]
      );
    }
    // Concepção vinda da planilha (acrescenta, não tira as que já existiam)
    const cache = new Map<string, string | null>();
    const vinculos: { developmentId: string; empresaId: string; papel: EmpresaPlanilha['papel'] }[] = [];
    for (const l of ligar) {
      const desta = new Map<string, EmpresaPlanilha['papel']>();
      for (const e of l.empresas.slice(0, 6)) {
        const empresaId = await resolverEmpresaImport({ nome: typeof e.nome === 'string' ? e.nome : undefined, cnpj: typeof e.cnpj === 'string' ? e.cnpj : undefined }, staff.email, cache);
        if (!empresaId) continue;
        const antes = desta.get(empresaId);
        desta.set(empresaId, antes && antes !== e.papel ? 'construtora_incorporadora' : e.papel);
      }
      for (const [empresaId, papel] of desta) vinculos.push({ developmentId: l.id, empresaId, papel });
    }
    await acrescentarConcepcao(vinculos);
    res.empresasLigadas = vinculos.length;
  } catch (e) {
    res.erros.push(e instanceof Error ? e.message.slice(0, 200) : 'Falha ao gravar o lote.');
  }
  return res;
}

// ---------------- Equipe (só o administrador gerencia) ----------------
export type MembroEquipe = { email: string; name: string; role: StaffRole; criadoEm: string; imoveis: number; telefone?: string | null };

const requireAdmin = exigirAdmin;

export async function listarEquipe(): Promise<MembroEquipe[]> {
  await requireAdmin();
  const rows = await query<{ email: string; name: string; role: StaffRole; created_at: string; imoveis: string; telefone: string | null }>(
    `select u.email, u.name, u.role, u.created_at, u.telefone,
        (select count(*) from properties p where p.corretor_email = u.email and p.is_tipologia = false) as imoveis
       from staff_users u order by case u.role when 'admin' then 0 when 'analista' then 1 else 2 end, u.name`
  );
  return rows.map((r) => ({ email: r.email, name: r.name, role: r.role, criadoEm: String(r.created_at), imoveis: Number(r.imoveis) || 0, telefone: r.telefone }));
}

/** Cria ou altera um membro. Senha em branco numa alteração = mantém a atual. */
export async function salvarMembro(m: { email: string; name: string; role: StaffRole; senha?: string; telefone?: string }): Promise<{ ok: boolean; erro?: string }> {
  const eu = await requireAdmin();
  const email = m.email.trim().toLowerCase();
  const name = m.name.trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, erro: 'E-mail inválido.' };
  if (!name) return { ok: false, erro: 'Informe o nome.' };
  if (!['admin', 'analista', 'corretor'].includes(m.role)) return { ok: false, erro: 'Papel inválido.' };
  if (email === eu.email && m.role !== 'admin') return { ok: false, erro: 'Você não pode tirar o seu próprio acesso de administrador.' };
  const existe = (await query<{ email: string }>('select email from staff_users where lower(email) = $1', [email])).length > 0;
  const senha = (m.senha ?? '').trim();
  if (!existe && senha.length < 8) return { ok: false, erro: 'Defina uma senha com pelo menos 8 caracteres.' };
  if (senha && senha.length < 8) return { ok: false, erro: 'A senha precisa ter pelo menos 8 caracteres.' };
  const hash = senha ? await bcrypt.hash(senha, 10) : null;
  if (existe) {
    // trocou a senha: derruba as sessões abertas dessa pessoa
    await query(
      'update staff_users set name = $2, role = $3, password_hash = coalesce($4::text, password_hash), sessoes_desde = case when $4::text is not null then now() else sessoes_desde end where lower(email) = $1',
      [email, name, m.role, hash]
    );
  } else {
    await query('insert into staff_users (email, name, role, password_hash) values ($1, $2, $3, $4)', [email, name, m.role, hash]);
  }
  // telefone: aparece na marca d'água do link "compartilhar com corretor"
  if (m.telefone !== undefined) await query('update staff_users set telefone = $2 where lower(email) = $1', [email, String(m.telefone).replace(/\D/g, '').slice(0, 13) || null]);
  return { ok: true };
}

/** Remove o acesso. Os imóveis que a pessoa cadastrou continuam no site (passam para quem removeu, se pedido). */
export async function removerMembro(email: string, transferirPara?: string): Promise<{ ok: boolean; erro?: string }> {
  const eu = await requireAdmin();
  if (email === eu.email) return { ok: false, erro: 'Você não pode remover a si mesmo.' };
  if (transferirPara) {
    await query('update properties set corretor_email = $2 where corretor_email = $1', [email, transferirPara]);
    await query('update developments set corretor_email = $2 where corretor_email = $1', [email, transferirPara]);
  }
  await query('delete from staff_users where email = $1', [email]);
  return { ok: true };
}

// Total de imóveis à venda (cabeçalho do feed): anúncios avulsos públicos à venda
// + condomínios/prédios lançamentos, novos e seminovos (entregues há até 6 anos),
// que também contam como anúncio.
export async function contarImoveisAVenda(): Promise<number> {
  const r = await query<{ n: string }>(
    `select (select count(*) from properties where is_tipologia = false and visibilidade = 'publico' and finalidade = 'venda' and vendido_em is null)
          + (select count(*) from developments where status = 'publicado' and delivery_date >= date_trunc('month', now()) - interval '60 months') as n`
  );
  return Number(r[0]?.n) || 0;
}

/** O feed está mostrando a visão da equipe (todos os condomínios)? */
export async function feedModoEquipe(): Promise<boolean> {
  return !!await currentStaff();
}

// "Condomínios neste bairro" (fim do feed quando a pessoa filtra por bairro):
// todos os condomínios publicados do bairro, só com o nome — inclusive os que
// não entram no feed — para quem quer explorar sem pesar a lista.
export type CondoDoBairro = { id: string; slug?: string; nome: string; bairro: string; anuncios: number };
export async function condominiosDosBairros(bairros: { nome: string; cidade: string }[]): Promise<CondoDoBairro[]> {
  const lista = bairros.slice(0, 5);
  if (!lista.length) return [];
  const conds: string[] = [];
  const params: unknown[] = [];
  for (const b of lista) {
    params.push(b.nome, b.cidade);
    const n = params.length;
    conds.push(`(${norm("coalesce(d.bairro, '')")} = ${norm(`$${n - 1}::text`)} and ${norm("coalesce(d.cidade, '')")} = ${norm(`$${n}::text`)})`);
  }
  const rows = await query<{ id: string; slug: string | null; name: string; bairro: string; anuncios: string }>(
    `select d.id, d.slug, d.name, d.bairro,
        (select count(*) from properties x where x.empreendimento_id = d.id and x.visibilidade = 'publico' and not x.is_tipologia and x.vendido_em is null) as anuncios
       from developments d
      where d.status = 'publicado' and (${conds.join(' or ')})
      order by anuncios desc, d.name limit 600`,
    params
  );
  return rows.map((r) => ({ id: r.id, slug: r.slug ?? undefined, nome: formatTitulo(r.name), bairro: r.bairro, anuncios: Number(r.anuncios) || 0 }));
}

/** Painel: gera as miniaturas das capas que faltam (feed leve). Rode até "restantes" = 0. */
export async function otimizarFotosDoFeed(): Promise<{ feitas: number; restantes: number; erros: string[] }> {
  await exigirGestor();
  return processarMiniaturas(20000);
}

// Lead do botão "Falar pelo WhatsApp": antes de abrir o WhatsApp a pessoa informa
// o nome (e, se quiser, o telefone) — fica em Painel → Interessados com o link do anúncio.
export async function registrarLeadWhatsapp(input: {
  nome: string;
  telefone?: string;
  titulo: string;
  caminho: string;
  condominio?: string;
  developmentId?: string;
}): Promise<{ ok: boolean; erro?: string }> {
  const nome = String(input.nome ?? '').trim().slice(0, 120);
  if (nome.length < 2) return { ok: false, erro: 'Digite seu nome.' };
  const telefone = String(input.telefone ?? '').replace(/[^\d]/g, '').slice(0, 13);
  const caminho = /^\/(imovel|empreendimento)\/[\w-]{1,80}$/.test(String(input.caminho)) ? String(input.caminho) : '';
  const titulo = String(input.titulo ?? '').slice(0, 200);
  const devId = input.developmentId && /^[\w-]{1,80}$/.test(input.developmentId) ? input.developmentId : null;
  const ip = ipDoVisitante();
  if (!(await dentroDoLimite(`lead:${ip}`, 15, 60))) return { ok: true }; // não trava a pessoa; só não grava de novo
  await registrarUso(`lead:${ip}`);
  await query(
    `insert into interest_leads (development_id, condominio, nome, telefone, finalidade, mensagem, aceita_contato, status)
     values ($1, $2, $3, $4, 'venda', $5, true, 'novo')`,
    [
      devId,
      formatTitulo(String(input.condominio || titulo).slice(0, 160)),
      nome,
      telefone || null,
      `Contato pelo WhatsApp: ${titulo}${caminho ? ` (${SITE_URL}${caminho})` : ''}`
    ]
  ).catch(() => {});
  return { ok: true };
}

// ---- Perfil informativo da empresa (construtora/incorporadora) ----
// Empreendimentos da Concepção da empresa, do mais novo para o mais antigo (pela
// entrega; breve lançamento primeiro). Paginado (sem rolagem infinita) e com filtros.
export type FiltrosEmpresa = { cidade?: string; bairro?: string; fase?: string; tipo?: string; q?: string };
export async function empreendimentosDaEmpresa(
  empresaIds: string | string[],
  filtros: FiltrosEmpresa,
  pagina: number,
  porPagina = 24
): Promise<{ cards: DevelopmentCardData[]; total: number; cidades: string[]; bairros: string[] }> {
  const ids = (Array.isArray(empresaIds) ? empresaIds : [empresaIds]).filter((i) => /^[0-9a-f-]{36}$/i.test(i));
  if (!ids.length) return { cards: [], total: 0, cidades: [], bairros: [] };
  const params: unknown[] = [ids];
  const conds = ["d.status = 'publicado'", 'de.empresa_id = any($1::uuid[])'];
  const p = (v: unknown) => {
    params.push(v);
    return `$${params.length}`;
  };
  const base = [...conds];
  if (filtros.cidade) conds.push(`lower(d.cidade) = lower(${p(filtros.cidade)})`);
  if (filtros.bairro) conds.push(`lower(d.bairro) = lower(${p(filtros.bairro)})`);
  if (filtros.tipo === 'vertical' || filtros.tipo === 'horizontal') conds.push(`d.tipo = ${p(filtros.tipo)}`);
  const fase = filtros.fase ? faseSql('d.delivery_date', filtros.fase) : null;
  if (fase) conds.push(fase);
  if (filtros.q?.trim()) conds.push(`translate(lower(d.name), 'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc') like ${p(`%${filtros.q.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')}%`)}`);
  const w = conds.join(' and ');
  const [lista, total, locais] = await Promise.all([
    query<{ id: string }>(
      `select distinct on (d.delivery_date, d.name, d.id) d.id from developments d join development_empresas de on de.development_id = d.id where ${w}
        order by d.delivery_date desc nulls last, d.name, d.id limit ${Math.min(60, porPagina)} offset ${Math.max(0, pagina) * porPagina}`,
      params
    ),
    query<{ n: string }>(`select count(distinct d.id) as n from developments d join development_empresas de on de.development_id = d.id where ${w}`, params),
    query<{ cidade: string | null; bairro: string | null }>(
      `select distinct d.cidade, d.bairro from developments d join development_empresas de on de.development_id = d.id where ${base.join(' and ')}`,
      [ids]
    )
  ]);
  const cardsDesordenados = await getDevelopmentCards(lista.map((r) => r.id));
  const ordem = new Map(lista.map((r, i) => [r.id, i]));
  const cards = cardsDesordenados.sort((a, b) => (ordem.get(a.id) ?? 0) - (ordem.get(b.id) ?? 0));
  const uniq = (v: (string | null)[]) => Array.from(new Set(v.filter((x): x is string => !!x))).sort((a, b) => a.localeCompare(b, 'pt-BR'));
  return { cards, total: Number(total[0]?.n) || 0, cidades: uniq(locais.map((l) => l.cidade)), bairros: uniq(locais.map((l) => l.bairro)) };
}

// ---------------- Mercado do bairro (números reais para a página) ----------------
export type MercadoDoBairro = {
  bairro: string;
  m2Anunciado: number | null; // média do R$/m² dos anúncios à venda no bairro
  anuncios: number;
  vendidos12m: number; // vendas registradas nos últimos 12 meses
  m2Vendido: number | null; // média do R$/m² dessas vendas
};

/** Números do bairro para as páginas de imóvel e condomínio (base da futura valorização). */
export async function mercadoDoBairro(cidade?: string | null, bairro?: string | null): Promise<MercadoDoBairro | null> {
  if (!cidade || !bairro) return null;
  const r = await query<{ m2: string | null; n: string; vendidos: string; m2v: string | null }>(
    `select
       (select avg(price_value / nullif(area, 0)) from properties
         where visibilidade = 'publico' and not is_tipologia and finalidade = 'venda' and vendido_em is null and price_value > 0 and area > 0
           and lower(cidade) = lower($1) and lower(coalesce(bairro, '')) = lower($2)) as m2,
       (select count(*) from properties
         where visibilidade = 'publico' and not is_tipologia and finalidade = 'venda' and vendido_em is null
           and lower(cidade) = lower($1) and lower(coalesce(bairro, '')) = lower($2)) as n,
       (select count(*) from imoveis_historico
         where motivo = 'vendido' and encerrado_em > now() - interval '12 months' and lower(cidade) = lower($1) and lower(coalesce(bairro, '')) = lower($2)) as vendidos,
       (select avg(valor_m2) from imoveis_historico
         where motivo = 'vendido' and encerrado_em > now() - interval '12 months' and lower(cidade) = lower($1) and lower(coalesce(bairro, '')) = lower($2)) as m2v`,
    [cidade, bairro]
  ).catch(() => []);
  const x = r[0];
  if (!x) return null;
  return {
    bairro,
    m2Anunciado: x.m2 ? Math.round(Number(x.m2)) : null,
    anuncios: Number(x.n) || 0,
    vendidos12m: Number(x.vendidos) || 0,
    m2Vendido: x.m2v ? Math.round(Number(x.m2v)) : null
  };
}
